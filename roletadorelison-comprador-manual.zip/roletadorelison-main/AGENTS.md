<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Raffle numbers are taken only through the `reserve_numbers` database function; tickets have no insert grant, so all limits (open status, range, phone required, no duplicates) live in one place.
- The admin overload of `reserve_numbers` assigns free numbers to registered buyers and changes payment status atomically; it preserves existing ownership and locks the raffle row to serialize reservations.
- Keep the paginated all-numbers admin table in its own component with shared row/selection logic, so free and occupied numbers remain selectable without expanding the management route.
- Prize-number ("cota premiada") numbers are never readable by non-admins; the public sees them only through `get_raffle_prizes_public`, which reveals a number once a paid ticket holds it.
- Buyer identity is never exposed publicly; taken numbers come from `get_raffle_taken` (numbers + status only).
- The first account ever created becomes admin via the signup trigger; further admins are added in `user_roles`.
- PIX key and contact WhatsApp live in the single-row `site_settings` table (`raffles.pix_key` is deprecated).
- Raffle images live in the private `raffle-images` bucket and are shown through signed URLs (workspace blocks public buckets).
- Selected raffle photos use a temporary object URL while uploading; persist only the private storage path so saved pages keep using signed URLs.
- Draw publication is validated by a database trigger and mirrored in `raffle-draw` for UI feedback: all tickets must be paid and each configured place gets a distinct paid number.
- Animate raffle draws with a dynamically imported `spin-wheel`; the authenticated server chooses the number using unbiased cryptographic randomness, excluding other places, and the animation lands on that result.
