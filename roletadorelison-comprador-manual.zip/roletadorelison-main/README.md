# Roletadorelison

oa noite lovable, quero fazer um site de rifa digital, com registro de usuários e etc vai ter 850 numero mais eu posso criar varias rifas com escolha de numero tipo 859 cotas e posso adicionar na rifa feita uma cita premiado no numero (exemplo 567) ganhador ganhara um premio para ter um registro de informações no login como emaim, nome completos e numero de contato para localizar o comprador premiado na cota e vai ser funcional.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://roletadorelison.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/4190cf9d-8ddc-44df-8066-d631d857e65b).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Compradores sem conta de login

No painel administrativo, acesse **Comprador manual** (rota `/admin/compradores`), escolha a rifa, informe o nome e, opcionalmente, o telefone, selecione números livres e marque se estão reservados ou pagos. Uma rifa padrão exibe os 850 números; alterações aceitam até 500 números por inclusão. Cada número entra na tabela normal de cotas e deixa de poder ser comprado ou reservado publicamente.

Antes de usar o recurso, aplique `drizzle/migrations/0009_manual_buyers.sql` ao banco de dados conectado. A migração permite cotas sem usuário autenticado e cria a função protegida por permissão de administrador que grava os números atomicamente.
