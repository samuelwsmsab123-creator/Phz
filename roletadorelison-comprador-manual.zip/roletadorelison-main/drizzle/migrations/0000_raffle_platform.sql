create type public.app_role as enum ('admin', 'user');

-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text not null default '',
  phone text not null default '',
  created_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;

-- USER ROLES
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create policy "Users read own roles" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

create policy "Users read own profile" on public.profiles
  for select to authenticated using (id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Users update own profile" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "Users insert own profile" on public.profiles
  for insert to authenticated with check (id = auth.uid());

-- New user: profile + first account becomes admin
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, email, phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', ''),
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data->>'phone', '')
  )
  on conflict (id) do nothing;

  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  insert into public.user_roles (user_id, role) values (new.id, 'user') on conflict do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- RAFFLES
create table public.raffles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  prize text not null default '',
  image_url text,
  total_numbers integer not null check (total_numbers between 1 and 100000),
  price numeric(10,2) not null default 0 check (price >= 0),
  pix_key text not null default '',
  status text not null default 'active' check (status in ('active', 'closed', 'finished')),
  draw_date timestamptz,
  winning_number integer,
  created_at timestamptz not null default now()
);
grant select on public.raffles to anon;
grant select, insert, update, delete on public.raffles to authenticated;
grant all on public.raffles to service_role;
alter table public.raffles enable row level security;

create policy "Anyone can view raffles" on public.raffles
  for select to anon, authenticated using (true);
create policy "Admins insert raffles" on public.raffles
  for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins update raffles" on public.raffles
  for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete raffles" on public.raffles
  for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

-- PRIZE NUMBERS (cotas premiadas)
create table public.raffle_prizes (
  id uuid primary key default gen_random_uuid(),
  raffle_id uuid not null references public.raffles(id) on delete cascade,
  number integer not null,
  prize text not null,
  created_at timestamptz not null default now(),
  unique (raffle_id, number)
);
grant select, insert, update, delete on public.raffle_prizes to authenticated;
grant all on public.raffle_prizes to service_role;
alter table public.raffle_prizes enable row level security;

create policy "Admins manage prizes" on public.raffle_prizes
  for all to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

-- TICKETS
create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  raffle_id uuid not null references public.raffles(id) on delete cascade,
  number integer not null,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'reserved' check (status in ('reserved', 'paid')),
  created_at timestamptz not null default now(),
  paid_at timestamptz,
  unique (raffle_id, number)
);
create index tickets_user_idx on public.tickets(user_id);
grant select, update, delete on public.tickets to authenticated;
grant all on public.tickets to service_role;
alter table public.tickets enable row level security;

create policy "Users see own tickets, admins all" on public.tickets
  for select to authenticated using (user_id = auth.uid() or public.has_role(auth.uid(), 'admin'));
create policy "Admins update tickets" on public.tickets
  for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete tickets, users cancel own reserved" on public.tickets
  for delete to authenticated using (
    public.has_role(auth.uid(), 'admin') or (user_id = auth.uid() and status = 'reserved')
  );

-- Public: which numbers are taken (no buyer info)
create or replace function public.get_raffle_numbers(_raffle_id uuid)
returns table (number integer, status text)
language sql
stable
security definer
set search_path = public
as $$
  select t.number, t.status from public.tickets t where t.raffle_id = _raffle_id
$$;
grant execute on function public.get_raffle_numbers(uuid) to anon, authenticated;

-- Public: prize list; number revealed only once a paid ticket holds it
create or replace function public.get_raffle_prizes_public(_raffle_id uuid)
returns table (id uuid, prize text, number integer, claimed boolean, winner_name text)
language sql
stable
security definer
set search_path = public
as $$
  select
    p.id,
    p.prize,
    case when t.id is not null then p.number else null end as number,
    (t.id is not null) as claimed,
    case when t.id is not null then split_part(pr.full_name, ' ', 1) else null end as winner_name
  from public.raffle_prizes p
  left join public.tickets t on t.raffle_id = p.raffle_id and t.number = p.number and t.status = 'paid'
  left join public.profiles pr on pr.id = t.user_id
  where p.raffle_id = _raffle_id
  order by p.created_at
$$;
grant execute on function public.get_raffle_prizes_public(uuid) to anon, authenticated;

-- Public: main draw winner first name
create or replace function public.get_raffle_winner(_raffle_id uuid)
returns table (number integer, winner_name text)
language sql
stable
security definer
set search_path = public
as $$
  select r.winning_number, split_part(pr.full_name, ' ', 1)
  from public.raffles r
  left join public.tickets t on t.raffle_id = r.id and t.number = r.winning_number and t.status = 'paid'
  left join public.profiles pr on pr.id = t.user_id
  where r.id = _raffle_id and r.winning_number is not null
$$;
grant execute on function public.get_raffle_winner(uuid) to anon, authenticated;

-- Signed-in user: prizes won by own paid tickets
create or replace function public.get_my_prizes()
returns table (raffle_id uuid, number integer, prize text)
language sql
stable
security definer
set search_path = public
as $$
  select p.raffle_id, p.number, p.prize
  from public.raffle_prizes p
  join public.tickets t on t.raffle_id = p.raffle_id and t.number = p.number
  where t.user_id = auth.uid() and t.status = 'paid'
$$;
grant execute on function public.get_my_prizes() to authenticated;

-- Reserve numbers
create or replace function public.reserve_numbers(_raffle_id uuid, _numbers integer[])
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  _uid uuid := auth.uid();
  _raffle public.raffles%rowtype;
  _taken text;
  _count integer;
  _phone text;
begin
  if _uid is null then
    raise exception 'Faça login para reservar números.';
  end if;

  select phone into _phone from public.profiles where id = _uid;
  if _phone is null or length(trim(_phone)) < 8 then
    raise exception 'Complete seu cadastro com um telefone antes de comprar.';
  end if;

  select * into _raffle from public.raffles where id = _raffle_id;
  if not found then
    raise exception 'Rifa não encontrada.';
  end if;
  if _raffle.status <> 'active' then
    raise exception 'Esta rifa não está aceitando novas compras.';
  end if;

  if _numbers is null or coalesce(array_length(_numbers, 1), 0) = 0 then
    raise exception 'Escolha pelo menos um número.';
  end if;
  if array_length(_numbers, 1) > 500 then
    raise exception 'Máximo de 500 números por compra.';
  end if;
  if exists (select 1 from unnest(_numbers) n where n < 1 or n > _raffle.total_numbers) then
    raise exception 'Número fora do intervalo da rifa.';
  end if;

  select string_agg(t.number::text, ', ' order by t.number) into _taken
  from public.tickets t
  where t.raffle_id = _raffle_id and t.number = any(_numbers);
  if _taken is not null then
    raise exception 'Estes números já foram escolhidos por outra pessoa: %', _taken;
  end if;

  insert into public.tickets (raffle_id, number, user_id)
  select _raffle_id, n, _uid from (select distinct unnest(_numbers) as n) s;
  get diagnostics _count = row_count;
  return _count;
exception
  when unique_violation then
    raise exception 'Algum número acabou de ser escolhido por outra pessoa. Atualize e tente de novo.';
end;
$$;
revoke execute on function public.reserve_numbers(uuid, integer[]) from anon, public;
grant execute on function public.reserve_numbers(uuid, integer[]) to authenticated;
