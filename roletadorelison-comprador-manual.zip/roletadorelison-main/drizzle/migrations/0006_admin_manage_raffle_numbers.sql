CREATE OR REPLACE FUNCTION public.reserve_numbers(_raffle_id uuid, _numbers integer[], _buyer_id uuid, _status text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _uid uuid := auth.uid();
  _admin boolean;
  _buyer uuid;
  _raffle public.raffles%rowtype;
  _count integer;
BEGIN
  IF _uid IS NULL THEN RAISE EXCEPTION 'Faça login para reservar números.'; END IF;
  _admin := public.has_role(_uid, 'admin');
  IF NOT _admin AND (_buyer_id IS DISTINCT FROM _uid OR _status IS DISTINCT FROM 'reserved') THEN
    RAISE EXCEPTION 'Somente o administrador pode gerenciar compradores e pagamentos.';
  END IF;
  IF _status IS NULL OR _status NOT IN ('paid', 'reserved') THEN RAISE EXCEPTION 'Escolha pago ou reservado.'; END IF;
  SELECT * INTO _raffle FROM public.raffles WHERE id = _raffle_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Rifa não encontrada.'; END IF;
  IF _raffle.winning_number IS NOT NULL OR _raffle.winning_number_2 IS NOT NULL OR _raffle.winning_number_3 IS NOT NULL THEN
    RAISE EXCEPTION 'Não é possível alterar cotas após o sorteio publicado.';
  END IF;
  IF _numbers IS NULL OR coalesce(array_length(_numbers, 1), 0) = 0 THEN RAISE EXCEPTION 'Escolha pelo menos um número.'; END IF;
  IF array_length(_numbers, 1) > 500 THEN RAISE EXCEPTION 'Máximo de 500 números por alteração.'; END IF;
  IF EXISTS (SELECT 1 FROM unnest(_numbers) n WHERE n IS NULL OR n < 1 OR n > _raffle.total_numbers) THEN
    RAISE EXCEPTION 'Número fora do intervalo da rifa.';
  END IF;
  IF NOT _admin AND EXISTS (SELECT 1 FROM public.tickets WHERE raffle_id = _raffle_id AND number = ANY(_numbers)) THEN
    RAISE EXCEPTION 'Algum número já foi escolhido por outra pessoa. Atualize e tente de novo.';
  END IF;
  IF EXISTS (SELECT 1 FROM unnest(_numbers) n WHERE NOT EXISTS (SELECT 1 FROM public.tickets t WHERE t.raffle_id = _raffle_id AND t.number = n)) THEN
    IF _raffle.status <> 'active' THEN RAISE EXCEPTION 'Esta rifa não está aceitando novas compras.'; END IF;
    IF _buyer_id IS NULL THEN RAISE EXCEPTION 'Escolha o comprador das cotas livres.'; END IF;
  END IF;
  IF _buyer_id IS NOT NULL THEN
    IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = _buyer_id AND length(trim(phone)) >= 8) THEN
      RAISE EXCEPTION 'O comprador precisa ter cadastro com telefone.';
    END IF;
    IF EXISTS (SELECT 1 FROM public.tickets WHERE raffle_id = _raffle_id AND number = ANY(_numbers) AND user_id <> _buyer_id) THEN
      RAISE EXCEPTION 'A seleção contém cotas de outro comprador. Não é possível trocar o titular.';
    END IF;
  END IF;
  INSERT INTO public.tickets (raffle_id, number, user_id, status, paid_at)
  SELECT _raffle_id, n, _buyer_id, _status, CASE WHEN _status = 'paid' THEN now() ELSE NULL END
  FROM (SELECT DISTINCT unnest(_numbers) n) s
  WHERE NOT EXISTS (SELECT 1 FROM public.tickets t WHERE t.raffle_id = _raffle_id AND t.number = s.n);
  UPDATE public.tickets SET status = _status, paid_at = CASE WHEN _status = 'paid' THEN coalesce(paid_at, now()) ELSE NULL END
  WHERE raffle_id = _raffle_id AND number = ANY(_numbers);
  GET DIAGNOSTICS _count = ROW_COUNT;
  RETURN _count;
EXCEPTION WHEN unique_violation THEN
  RAISE EXCEPTION 'Algum número acabou de ser escolhido por outra pessoa. Atualize e tente de novo.';
END;
$$;
REVOKE ALL ON FUNCTION public.reserve_numbers(uuid, integer[], uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.reserve_numbers(uuid, integer[], uuid, text) TO authenticated;
CREATE OR REPLACE FUNCTION public.reserve_numbers(_raffle_id uuid, _numbers integer[])
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.tickets WHERE raffle_id = _raffle_id AND number = ANY(_numbers)) THEN
    RAISE EXCEPTION 'Algum número já foi escolhido por outra pessoa. Atualize e tente de novo.';
  END IF;
  RETURN public.reserve_numbers(_raffle_id, _numbers, auth.uid(), 'reserved');
END;
$$;
REVOKE ALL ON FUNCTION public.reserve_numbers(uuid, integer[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.reserve_numbers(uuid, integer[]) TO authenticated;