create table public.site_settings (
  id integer primary key default 1 check (id = 1),
  pix_key text not null default '',
  pix_holder text not null default '',
  contact_phone text not null default '',
  updated_at timestamptz not null default now()
);
grant select on public.site_settings to anon;
grant select, update on public.site_settings to authenticated;
grant all on public.site_settings to service_role;
alter table public.site_settings enable row level security;

create policy "Anyone can read settings" on public.site_settings
  for select to anon, authenticated using (true);
create policy "Admins update settings" on public.site_settings
  for update to authenticated using (public.has_role(auth.uid(), 'admin')) with check (public.has_role(auth.uid(), 'admin'));

insert into public.site_settings (id) values (1);

comment on column public.raffles.pix_key is 'DEPRECATED: replaced by site_settings.pix_key';

create policy "Anyone can view raffle images" on storage.objects
  for select to anon, authenticated using (bucket_id = 'raffle-images');
create policy "Admins upload raffle images" on storage.objects
  for insert to authenticated with check (bucket_id = 'raffle-images' and public.has_role(auth.uid(), 'admin'));
create policy "Admins update raffle images" on storage.objects
  for update to authenticated using (bucket_id = 'raffle-images' and public.has_role(auth.uid(), 'admin'));
create policy "Admins delete raffle images" on storage.objects
  for delete to authenticated using (bucket_id = 'raffle-images' and public.has_role(auth.uid(), 'admin'));
