create or replace function public.get_raffle_taken(_raffle_id uuid)
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'reserved', coalesce((select jsonb_agg(number order by number) from public.tickets where raffle_id = _raffle_id and status = 'reserved'), '[]'::jsonb),
    'paid', coalesce((select jsonb_agg(number order by number) from public.tickets where raffle_id = _raffle_id and status = 'paid'), '[]'::jsonb)
  )
$$;
grant execute on function public.get_raffle_taken(uuid) to anon, authenticated;

create or replace function public.get_raffles_progress()
returns table (raffle_id uuid, taken integer)
language sql
stable
security definer
set search_path = public
as $$
  select raffle_id, count(*)::int from public.tickets group by raffle_id
$$;
grant execute on function public.get_raffles_progress() to anon, authenticated;
