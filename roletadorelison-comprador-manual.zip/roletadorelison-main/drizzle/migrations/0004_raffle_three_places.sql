ALTER TABLE public.raffles
  ADD COLUMN prize_2 text NOT NULL DEFAULT '',
  ADD COLUMN prize_3 text NOT NULL DEFAULT '',
  ADD COLUMN winning_number_2 integer,
  ADD COLUMN winning_number_3 integer;

DROP FUNCTION public.get_raffle_winner(uuid);

CREATE FUNCTION public.get_raffle_winner(_raffle_id uuid)
RETURNS TABLE(place integer, number integer, winner_name text, prize text)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  select v.place, v.number,
         split_part(pr.full_name, ' ', 1) as winner_name,
         v.prize
  from public.raffles r
  cross join lateral (
    values
      (1, r.winning_number, r.prize),
      (2, r.winning_number_2, r.prize_2),
      (3, r.winning_number_3, r.prize_3)
  ) as v(place, number, prize)
  left join public.tickets t
    on t.raffle_id = r.id and t.number = v.number and t.status = 'paid'
  left join public.profiles pr on pr.id = t.user_id
  where r.id = _raffle_id and v.number is not null
  order by v.place
$function$;