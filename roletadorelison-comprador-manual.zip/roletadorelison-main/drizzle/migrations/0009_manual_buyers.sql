-- Compradores cadastrados pelo administrador não precisam criar uma conta de autenticação.
ALTER TABLE public.tickets ALTER COLUMN user_id DROP NOT NULL;
ALTER TABLE public.tickets ADD COLUMN manual_buyer_name text;
ALTER TABLE public.tickets ADD COLUMN manual_buyer_phone text;
ALTER TABLE public.tickets ADD CONSTRAINT tickets_buyer_identity_check CHECK (
  (user_id IS NOT NULL AND manual_buyer_name IS NULL AND manual_buyer_phone IS NULL)
  OR (user_id IS NULL AND nullif(btrim(manual_buyer_name), '') IS NOT NULL)
);

-- A atribuição é atômica: cada número entra na mesma tabela que a compra pública
-- e a restrição UNIQUE (raffle_id, number) impede reservas concorrentes duplicadas.
CREATE OR REPLACE FUNCTION public.admin_add_manual_buyer(
  _raffle_id uuid,
  _numbers integer[],
  _buyer_name text,
  _buyer_phone text DEFAULT '',
  _status text DEFAULT 'reserved'
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _raffle public.raffles%rowtype;
  _count integer;
  _name text := btrim(coalesce(_buyer_name, ''));
  _phone text := nullif(btrim(coalesce(_buyer_phone, '')), '');
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Somente o administrador pode cadastrar compradores manuais.';
  END IF;
  IF length(_name) < 2 OR length(_name) > 160 THEN
    RAISE EXCEPTION 'Informe o nome do comprador (até 160 caracteres).';
  END IF;
  IF _phone IS NOT NULL AND length(_phone) > 30 THEN
    RAISE EXCEPTION 'O telefone deve ter até 30 caracteres.';
  END IF;
  IF _status IS NULL OR _status NOT IN ('paid', 'reserved') THEN
    RAISE EXCEPTION 'Escolha pago ou reservado.';
  END IF;
  SELECT * INTO _raffle FROM public.raffles WHERE id = _raffle_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Rifa não encontrada.'; END IF;
  IF _raffle.status <> 'active' THEN
    RAISE EXCEPTION 'Esta rifa não está aceitando novos números.';
  END IF;
  IF _raffle.winning_number IS NOT NULL OR _raffle.winning_number_2 IS NOT NULL OR _raffle.winning_number_3 IS NOT NULL THEN
    RAISE EXCEPTION 'Não é possível alterar números após o sorteio publicado.';
  END IF;
  IF _numbers IS NULL OR coalesce(array_length(_numbers, 1), 0) = 0 THEN
    RAISE EXCEPTION 'Selecione pelo menos um número.';
  END IF;
  IF array_length(_numbers, 1) > 500 THEN
    RAISE EXCEPTION 'Máximo de 500 números por inclusão.';
  END IF;
  IF EXISTS (SELECT 1 FROM unnest(_numbers) n WHERE n IS NULL OR n < 1 OR n > _raffle.total_numbers) THEN
    RAISE EXCEPTION 'Número fora do intervalo da rifa.';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.tickets t
    WHERE t.raffle_id = _raffle_id AND t.number = ANY(_numbers)
  ) THEN
    RAISE EXCEPTION 'Um ou mais números já foram comprados ou reservados. Atualize a tabela e tente novamente.';
  END IF;

  INSERT INTO public.tickets (raffle_id, number, user_id, manual_buyer_name, manual_buyer_phone, status, paid_at)
  SELECT _raffle_id, n, NULL, _name, _phone, _status, CASE WHEN _status = 'paid' THEN now() ELSE NULL END
  FROM (SELECT DISTINCT unnest(_numbers) AS n) selected_numbers;
  GET DIAGNOSTICS _count = ROW_COUNT;
  RETURN _count;
EXCEPTION
  WHEN unique_violation THEN
    RAISE EXCEPTION 'Um número acabou de ser comprado ou reservado. Atualize a tabela e tente novamente.';
END;
$$;

REVOKE ALL ON FUNCTION public.admin_add_manual_buyer(uuid, integer[], text, text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_add_manual_buyer(uuid, integer[], text, text, text) TO authenticated;

-- Resultados públicos continuam mostrando somente o primeiro nome, seja perfil autenticado ou cadastro manual.
CREATE OR REPLACE FUNCTION public.get_raffle_winner(_raffle_id uuid)
RETURNS TABLE(place integer, number integer, winner_name text, prize text)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT v.place, v.number,
         coalesce(split_part(pr.full_name, ' ', 1), split_part(t.manual_buyer_name, ' ', 1)) AS winner_name,
         v.prize
  FROM public.raffles r
  CROSS JOIN LATERAL (
    VALUES
      (1, r.winning_number, r.prize),
      (2, r.winning_number_2, r.prize_2),
      (3, r.winning_number_3, r.prize_3)
  ) AS v(place, number, prize)
  LEFT JOIN public.tickets t
    ON t.raffle_id = r.id AND t.number = v.number AND t.status = 'paid'
  LEFT JOIN public.profiles pr ON pr.id = t.user_id
  WHERE r.id = _raffle_id AND v.number IS NOT NULL
  ORDER BY v.place
$function$;

CREATE OR REPLACE FUNCTION public.get_raffle_prizes_public(_raffle_id uuid)
RETURNS TABLE(id uuid, prize text, number integer, claimed boolean, winner_name text)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.id,
         p.prize,
         CASE WHEN t.id IS NOT NULL THEN p.number ELSE NULL END AS number,
         (t.id IS NOT NULL) AS claimed,
         CASE WHEN t.id IS NOT NULL
           THEN coalesce(split_part(pr.full_name, ' ', 1), split_part(t.manual_buyer_name, ' ', 1))
           ELSE NULL
         END AS winner_name
  FROM public.raffle_prizes p
  LEFT JOIN public.tickets t ON t.raffle_id = p.raffle_id AND t.number = p.number AND t.status = 'paid'
  LEFT JOIN public.profiles pr ON pr.id = t.user_id
  WHERE p.raffle_id = _raffle_id
  ORDER BY p.created_at
$$;
