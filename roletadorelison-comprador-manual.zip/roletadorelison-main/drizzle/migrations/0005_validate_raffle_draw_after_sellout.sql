create or replace function public.validate_raffle_draw() returns trigger language plpgsql set search_path=public as $$
declare winners integer[]; n integer;
begin
  if new.winning_number is null and new.winning_number_2 is null and new.winning_number_3 is null then return new; end if;
  if tg_op = 'UPDATE' then
    if new.winning_number is not distinct from old.winning_number and new.winning_number_2 is not distinct from old.winning_number_2 and new.winning_number_3 is not distinct from old.winning_number_3 and not (new.status='finished' and old.status is distinct from 'finished') then return new; end if;
  end if;
  if (select count(*) from public.tickets where raffle_id=new.id and status='paid') <> new.total_numbers then raise exception 'O sorteio só pode ser publicado quando todas as cotas estiverem pagas.'; end if;
  if new.winning_number is null or (btrim(new.prize_2) <> '' and new.winning_number_2 is null) or (btrim(new.prize_3) <> '' and new.winning_number_3 is null) then raise exception 'Informe um número para cada lugar com prêmio.'; end if;
  winners:=array_remove(array[new.winning_number,new.winning_number_2,new.winning_number_3],null);
  if (select count(distinct x) from unnest(winners) x) <> cardinality(winners) then raise exception 'Escolha um número diferente para cada lugar.'; end if;
  foreach n in array winners loop
    if n < 1 or n > new.total_numbers then raise exception 'Número fora da quantidade de cotas da rifa.'; end if;
    if not exists(select 1 from public.tickets where raffle_id=new.id and number=n and status='paid') then raise exception 'O número sorteado precisa estar pago.'; end if;
  end loop;
  return new;
end; $$;
revoke all on function public.validate_raffle_draw() from public, anon, authenticated;
create trigger validate_raffle_draw_before_save before insert or update on public.raffles for each row execute function public.validate_raffle_draw();