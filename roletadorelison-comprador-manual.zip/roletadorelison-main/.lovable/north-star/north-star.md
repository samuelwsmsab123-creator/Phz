<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Compradores garantem seus números da rifa e os ganhadores recebem seus prêmios.

## Métrica

Cotas de rifa confirmadas como pagas por semana
