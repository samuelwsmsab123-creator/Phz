export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      profiles: {
        Row: {
          created_at: string
          email: string
          full_name: string
          id: string
          phone: string
        }
        Insert: {
          created_at?: string
          email?: string
          full_name?: string
          id: string
          phone?: string
        }
        Update: {
          created_at?: string
          email?: string
          full_name?: string
          id?: string
          phone?: string
        }
        Relationships: []
      }
      raffle_prizes: {
        Row: {
          created_at: string
          id: string
          number: number
          prize: string
          raffle_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          number: number
          prize: string
          raffle_id: string
        }
        Update: {
          created_at?: string
          id?: string
          number?: number
          prize?: string
          raffle_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "raffle_prizes_raffle_id_fkey"
            columns: ["raffle_id"]
            isOneToOne: false
            referencedRelation: "raffles"
            referencedColumns: ["id"]
          },
        ]
      }
      raffles: {
        Row: {
          created_at: string
          description: string
          draw_date: string | null
          id: string
          image_url: string | null
          pix_key: string
          price: number
          prize: string
          prize_2: string
          prize_3: string
          status: string
          title: string
          total_numbers: number
          winning_number: number | null
          winning_number_2: number | null
          winning_number_3: number | null
        }
        Insert: {
          created_at?: string
          description?: string
          draw_date?: string | null
          id?: string
          image_url?: string | null
          pix_key?: string
          price?: number
          prize?: string
          prize_2?: string
          prize_3?: string
          status?: string
          title: string
          total_numbers: number
          winning_number?: number | null
          winning_number_2?: number | null
          winning_number_3?: number | null
        }
        Update: {
          created_at?: string
          description?: string
          draw_date?: string | null
          id?: string
          image_url?: string | null
          pix_key?: string
          price?: number
          prize?: string
          prize_2?: string
          prize_3?: string
          status?: string
          title?: string
          total_numbers?: number
          winning_number?: number | null
          winning_number_2?: number | null
          winning_number_3?: number | null
        }
        Relationships: []
      }
      site_settings: {
        Row: {
          contact_phone: string
          id: number
          pix_holder: string
          pix_key: string
          updated_at: string
        }
        Insert: {
          contact_phone?: string
          id?: number
          pix_holder?: string
          pix_key?: string
          updated_at?: string
        }
        Update: {
          contact_phone?: string
          id?: number
          pix_holder?: string
          pix_key?: string
          updated_at?: string
        }
        Relationships: []
      }
      tickets: {
        Row: {
          created_at: string
          id: string
          manual_buyer_name: string | null
          manual_buyer_phone: string | null
          number: number
          paid_at: string | null
          raffle_id: string
          status: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          manual_buyer_name?: string | null
          manual_buyer_phone?: string | null
          number: number
          paid_at?: string | null
          raffle_id: string
          status?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          manual_buyer_name?: string | null
          manual_buyer_phone?: string | null
          number?: number
          paid_at?: string | null
          raffle_id?: string
          status?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tickets_raffle_id_fkey"
            columns: ["raffle_id"]
            isOneToOne: false
            referencedRelation: "raffles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tickets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_add_manual_buyer: {
        Args: {
          _buyer_name: string
          _buyer_phone?: string
          _numbers: number[]
          _raffle_id: string
          _status?: string
        }
        Returns: number
      }
      admin_manage_numbers: {
        Args: {
          _buyer_id?: string
          _numbers: number[]
          _raffle_id: string
          _status: string
        }
        Returns: number
      }
      get_my_prizes: {
        Args: never
        Returns: {
          number: number
          prize: string
          raffle_id: string
        }[]
      }
      get_raffle_numbers: {
        Args: { _raffle_id: string }
        Returns: {
          number: number
          status: string
        }[]
      }
      get_raffle_prizes_public: {
        Args: { _raffle_id: string }
        Returns: {
          claimed: boolean
          id: string
          number: number
          prize: string
          winner_name: string
        }[]
      }
      get_raffle_taken: { Args: { _raffle_id: string }; Returns: Json }
      get_raffle_winner: {
        Args: { _raffle_id: string }
        Returns: {
          number: number
          place: number
          prize: string
          winner_name: string
        }[]
      }
      get_raffles_progress: {
        Args: never
        Returns: {
          raffle_id: string
          taken: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      reserve_numbers:
        | { Args: { _numbers: number[]; _raffle_id: string }; Returns: number }
        | {
            Args: {
              _buyer_id: string
              _numbers: number[]
              _raffle_id: string
              _status: string
            }
            Returns: number
          }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
