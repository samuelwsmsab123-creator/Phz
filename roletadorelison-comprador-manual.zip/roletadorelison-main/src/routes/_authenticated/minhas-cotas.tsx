import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { PartyPopper, Ticket } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { PixDialog } from "@/components/site/pix-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { myPrizesQuery, myTicketsQuery } from "@/lib/queries";
import { errorMessage, formatBRL, formatNumber, STATUS_LABEL } from "@/lib/raffle";

export const Route = createFileRoute("/_authenticated/minhas-cotas")({
  head: () => ({
    meta: [
      { title: "Minhas cotas — Roleta Do Relison" },
      { name: "description", content: "Acompanhe seus números reservados, pagos e prêmios." },
      { property: "og:title", content: "Minhas cotas — Roleta Do Relison" },
      { property: "og:description", content: "Seus números e prêmios na Roleta Do Relison." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: MyTickets,
});

function MyTickets() {
  const { user } = useAuth();
  const uid = user?.id ?? "";
  const qc = useQueryClient();
  const tickets = useQuery({ ...myTicketsQuery(uid), enabled: !!uid });
  const prizes = useQuery({ ...myPrizesQuery(uid), enabled: !!uid });
  const [pix, setPix] = useState<{ amount: number; numbers: string[]; title: string } | null>(null);

  const cancel = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await supabase.from("tickets").delete().in("id", ids).eq("status", "reserved");
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Reserva cancelada.");
      qc.invalidateQueries({ queryKey: ["my-tickets"] });
      qc.invalidateQueries({ queryKey: ["raffle-taken"] });
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  const groups = new Map<string, NonNullable<typeof tickets.data>>();
  for (const t of tickets.data ?? []) {
    const arr = groups.get(t.raffle_id) ?? [];
    arr.push(t);
    groups.set(t.raffle_id, arr);
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-4xl font-extrabold">Minhas cotas</h1>
      <p className="text-muted-foreground">Seus números em todas as rifas.</p>

      {(prizes.data?.length ?? 0) > 0 && (
        <div className="mt-6 space-y-2 rounded-3xl bg-gradient-ink p-6 text-ink-foreground">
          <div className="flex items-center gap-2 font-display text-xl font-bold text-gold">
            <PartyPopper className="size-6" /> Parabéns! Você encontrou cota premiada
          </div>
          {prizes.data!.map((p) => {
            const g = groups.get(p.raffle_id)?.[0]?.raffles;
            return (
              <div key={`${p.raffle_id}-${p.number}`} className="text-sm">
                Número <strong className="text-gold">{g ? formatNumber(p.number, g.total_numbers) : p.number}</strong>
                {g ? ` em "${g.title}"` : ""}: <strong>{p.prize}</strong>. O organizador vai entrar em contato.
              </div>
            );
          })}
        </div>
      )}

      <div className="mt-8 space-y-5">
        {tickets.isLoading && <Skeleton className="h-40 rounded-3xl" />}
        {!tickets.isLoading && groups.size === 0 && (
          <div className="rounded-3xl border border-dashed border-border p-10 text-center">
            <Ticket className="mx-auto size-10 text-muted-foreground" />
            <p className="mt-3 text-muted-foreground">Você ainda não tem números.</p>
            <Button asChild className="mt-4"><Link to="/">Ver rifas</Link></Button>
          </div>
        )}
        {[...groups.entries()].map(([raffleId, list]) => {
          const r = list[0]?.raffles;
          if (!r) return null;
          const reserved = list.filter((t) => t.status === "reserved");
          const paidList = list.filter((t) => t.status === "paid");
          return (
            <div key={raffleId} className="rounded-3xl border border-border bg-card p-5 shadow-ticket">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <Link to="/rifa/$id" params={{ id: raffleId }} className="font-display text-xl font-bold hover:underline">
                    {r.title}
                  </Link>
                  <div className="mt-1 flex flex-wrap gap-2">
                    <Badge variant="secondary">{STATUS_LABEL[r.status] ?? r.status}</Badge>
                    {[
                      { place: "1º", n: r.winning_number },
                      { place: "2º", n: r.winning_number_2 },
                      { place: "3º", n: r.winning_number_3 },
                    ]
                      .filter((w) => w.n != null)
                      .map((w) => (
                        <Badge key={w.place} variant="outline">{w.place} lugar: {formatNumber(w.n!, r.total_numbers)}</Badge>
                      ))}
                  </div>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  {paidList.length} pagos · {reserved.length} aguardando
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-1.5">
                {list.map((t) => (
                  <span
                    key={t.id}
                    className="num-cell px-2.5"
                    data-state={[r.winning_number, r.winning_number_2, r.winning_number_3].includes(t.number) ? "mine" : t.status === "paid" ? "paid" : "reserved"}
                  >
                    {formatNumber(t.number, r.total_numbers)}
                  </span>
                ))}
              </div>
              {reserved.length > 0 && (
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl bg-warning/15 p-3">
                  <span className="text-sm">
                    A pagar: <strong>{formatBRL(reserved.length * Number(r.price))}</strong>
                  </span>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={cancel.isPending}
                      onClick={() => {
                        if (confirm("Cancelar os números reservados desta rifa?")) cancel.mutate(reserved.map((t) => t.id));
                      }}
                    >
                      Cancelar reserva
                    </Button>
                    <Button
                      size="sm"
                      variant="gold"
                      onClick={() =>
                        setPix({
                          amount: reserved.length * Number(r.price),
                          numbers: reserved.map((t) => formatNumber(t.number, r.total_numbers)),
                          title: r.title,
                        })
                      }
                    >
                      Pagar via PIX
                    </Button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {pix && (
        <PixDialog open onOpenChange={(v) => !v && setPix(null)} amount={pix.amount} numbers={pix.numbers} raffleTitle={pix.title} />
      )}
    </div>
  );
}
