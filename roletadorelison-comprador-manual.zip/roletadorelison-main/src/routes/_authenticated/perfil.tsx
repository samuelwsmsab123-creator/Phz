import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { errorMessage, formatPhone, onlyDigits } from "@/lib/raffle";

export const Route = createFileRoute("/_authenticated/perfil")({
  head: () => ({
    meta: [
      { title: "Meu perfil — Roleta Do Relison" },
      { name: "description", content: "Atualize seu nome e telefone de contato." },
      { property: "og:title", content: "Meu perfil — Roleta Do Relison" },
      { property: "og:description", content: "Seus dados de contato na Roleta Do Relison." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Profile,
});

function Profile() {
  const { user, profile } = useAuth();
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (profile) {
      setName(profile.full_name);
      setPhone(formatPhone(profile.phone));
    }
  }, [profile]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    if (name.trim().split(/\s+/).length < 2) { toast.error("Informe seu nome completo."); return; }
    if (onlyDigits(phone).length < 10) { toast.error("Informe um telefone com DDD."); return; }
    setBusy(true);
    const { error } = await supabase.from("profiles").update({ full_name: name.trim(), phone }).eq("id", user.id);
    setBusy(false);
    if (error) { toast.error(errorMessage(error)); return; }
    toast.success("Dados salvos!");
    qc.invalidateQueries({ queryKey: ["profile", user.id] });
  }

  return (
    <div className="mx-auto max-w-md px-4 py-10">
      <form onSubmit={save} className="space-y-4 rounded-3xl border border-border bg-card p-7 shadow-ticket">
        <h1 className="text-3xl font-extrabold">Meu perfil</h1>
        <p className="-mt-2 text-sm text-muted-foreground">Esses dados são usados para contatar você se ganhar.</p>
        <div className="space-y-1.5">
          <Label>E-mail</Label>
          <Input value={user?.email ?? ""} disabled />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-name">Nome completo</Label>
          <Input id="pf-name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pf-phone">Telefone / WhatsApp</Label>
          <Input id="pf-phone" inputMode="tel" value={phone} onChange={(e) => setPhone(formatPhone(e.target.value))} />
        </div>
        <Button type="submit" className="w-full" disabled={busy}>{busy ? "Salvando..." : "Salvar"}</Button>
      </form>
    </div>
  );
}
