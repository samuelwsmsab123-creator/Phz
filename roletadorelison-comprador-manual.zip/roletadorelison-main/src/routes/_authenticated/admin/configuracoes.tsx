import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { settingsQuery } from "@/lib/queries";
import { errorMessage, formatPhone } from "@/lib/raffle";

export const Route = createFileRoute("/_authenticated/admin/configuracoes")({
  head: () => ({
    meta: [
      { title: "PIX e contato — Admin Roleta Do Relison" },
      { name: "description", content: "Configure a chave PIX e o WhatsApp de contato das rifas." },
      { property: "og:title", content: "PIX e contato — Admin" },
      { property: "og:description", content: "Configurações de pagamento da Roleta Do Relison." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Settings,
});

function Settings() {
  const qc = useQueryClient();
  const s = useQuery(settingsQuery());
  const [form, setForm] = useState({ pix_key: "", pix_holder: "", contact_phone: "" });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (s.data) setForm({ pix_key: s.data.pix_key, pix_holder: s.data.pix_holder, contact_phone: formatPhone(s.data.contact_phone) });
  }, [s.data]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase
      .from("site_settings")
      .update({ ...form, pix_key: form.pix_key.trim(), updated_at: new Date().toISOString() })
      .eq("id", 1);
    setBusy(false);
    if (error) { toast.error(errorMessage(error)); return; }
    toast.success("Configurações salvas!");
    qc.invalidateQueries({ queryKey: ["site-settings"] });
  }

  return (
    <form onSubmit={save} className="max-w-xl space-y-5 rounded-3xl border border-border bg-card p-6 shadow-ticket">
      <div>
        <h2 className="text-2xl font-bold">Pagamento via PIX</h2>
        <p className="text-sm text-muted-foreground">Essa chave aparece para o comprador logo após reservar os números.</p>
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="pix">Chave PIX</Label>
        <Input id="pix" placeholder="CPF, e-mail, telefone ou chave aleatória" value={form.pix_key} onChange={(e) => setForm({ ...form, pix_key: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="holder">Nome do titular</Label>
        <Input id="holder" value={form.pix_holder} onChange={(e) => setForm({ ...form, pix_holder: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="wa">WhatsApp para receber comprovantes</Label>
        <Input id="wa" inputMode="tel" placeholder="(11) 91234-5678" value={form.contact_phone} onChange={(e) => setForm({ ...form, contact_phone: formatPhone(e.target.value) })} />
      </div>
      <Button type="submit" disabled={busy}>{busy ? "Salvando..." : "Salvar"}</Button>
    </form>
  );
}
