import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, ChevronLeft, ChevronRight, Search, UserPlus, X } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { adminTicketsQuery, rafflesQuery, type AdminTicket } from "@/lib/queries";
import { errorMessage, formatNumber } from "@/lib/raffle";

const PAGE_SIZE = 100;
const EMPTY_TICKETS: AdminTicket[] = [];

export const Route = createFileRoute("/_authenticated/admin/compradores")({
  head: () => ({
    meta: [
      { title: "Adicionar comprador — Roleta Do Relison" },
      { name: "description", content: "Atribua números da rifa a compradores sem conta de login." },
    ],
  }),
  component: ManualBuyersPage,
});

function ManualBuyersPage() {
  const queryClient = useQueryClient();
  const raffles = useQuery(rafflesQuery());
  const [raffleId, setRaffleId] = useState("");
  const [buyerName, setBuyerName] = useState("");
  const [buyerPhone, setBuyerPhone] = useState("");
  const [status, setStatus] = useState<"reserved" | "paid">("reserved");
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Set<number>>(new Set());

  const selectedRaffleId = raffleId || raffles.data?.[0]?.id || "";
  const raffle = raffles.data?.find((item) => item.id === selectedRaffleId);
  const ticketsQuery = useQuery({
    ...adminTicketsQuery(selectedRaffleId),
    enabled: !!selectedRaffleId,
  });
  const tickets = ticketsQuery.data ?? EMPTY_TICKETS;
  const byNumber = useMemo(
    () => new Map<number, AdminTicket>(tickets.map((ticket) => [ticket.number, ticket])),
    [tickets],
  );
  const rows = useMemo(
    () =>
      raffle
        ? Array.from({ length: raffle.total_numbers }, (_, index) => {
            const number = index + 1;
            const ticket = byNumber.get(number);
            return {
              number,
              ticket,
              status: ticket?.status ?? "free",
              buyerName: ticket?.profiles?.full_name || ticket?.manual_buyer_name || "",
            };
          })
        : [],
    [raffle, byNumber],
  );
  const term = search.trim().toLocaleLowerCase("pt-BR");
  const filtered = rows.filter(
    (row) =>
      (filter === "all" || row.status === filter) &&
      (!term ||
        row.buyerName.toLocaleLowerCase("pt-BR").includes(term) ||
        String(row.number) === term ||
        (raffle ? formatNumber(row.number, raffle.total_numbers) === term : false)),
  );
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount - 1);
  const visible = filtered.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);
  const freeVisible = visible.filter((row) => row.status === "free");
  const pageSelected =
    freeVisible.length > 0 && freeVisible.every((row) => selected.has(row.number));
  const drawLocked =
    !!raffle &&
    (raffle.winning_number != null ||
      raffle.winning_number_2 != null ||
      raffle.winning_number_3 != null);
  const canAdd = !!raffle && raffle.status === "active" && !drawLocked;
  const nameError = buyerName.trim().length < 2 ? "Informe o nome do comprador." : null;
  const selectionError =
    selected.size === 0
      ? "Selecione pelo menos um número livre."
      : selected.size > 500
        ? "Você pode adicionar até 500 números por vez. Faça mais de uma inclusão para os 850 números."
        : null;

  const addBuyer = useMutation({
    mutationFn: async () => {
      if (!selectedRaffleId) throw new Error("Selecione uma rifa.");
      if (nameError) throw new Error(nameError);
      if (selectionError) throw new Error(selectionError);
      const { error } = await supabase.rpc("admin_add_manual_buyer", {
        _raffle_id: selectedRaffleId,
        _numbers: [...selected].sort((a, b) => a - b),
        _buyer_name: buyerName.trim(),
        _buyer_phone: buyerPhone.trim(),
        _status: status,
      });
      if (error) throw error;
    },
    onSuccess: async () => {
      toast.success("Comprador adicionado e números bloqueados na rifa pública.");
      setSelected(new Set());
      setBuyerName("");
      setBuyerPhone("");
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["admin-tickets", selectedRaffleId] }),
        queryClient.invalidateQueries({ queryKey: ["raffle-taken", selectedRaffleId] }),
        queryClient.invalidateQueries({ queryKey: ["raffles-progress"] }),
      ]);
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  function toggle(number: number) {
    setSelected((previous) => {
      const next = new Set(previous);
      if (next.has(number)) next.delete(number);
      else if (next.size < 500) next.add(number);
      else toast.error("O limite é 500 números por inclusão.");
      return next;
    });
  }

  function changeRaffle(value: string) {
    setRaffleId(value);
    setSelected(new Set());
    setPage(0);
    setSearch("");
    setFilter("all");
  }

  if (raffles.isLoading) return <Skeleton className="h-96 rounded-3xl" />;
  if (raffles.isError)
    return (
      <p role="alert" className="text-sm text-destructive">
        Não foi possível carregar as rifas.
      </p>
    );
  if (!raffles.data?.length)
    return (
      <div className="rounded-2xl border border-dashed border-border p-8 text-center text-muted-foreground">
        Crie uma rifa antes de adicionar compradores.
      </div>
    );

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-display text-2xl font-bold">Adicionar comprador sem login</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Escolha a rifa, informe o comprador e marque os números. Os números atribuídos deixam de
          aparecer como disponíveis para compra ou reserva pública.
        </p>
      </div>

      <section className="space-y-4 rounded-2xl border border-border bg-card p-4 sm:p-5">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4 lg:items-end">
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="manual-raffle">Rifa</Label>
            <Select value={selectedRaffleId} onValueChange={changeRaffle}>
              <SelectTrigger id="manual-raffle">
                <SelectValue placeholder="Selecione uma rifa" />
              </SelectTrigger>
              <SelectContent>
                {raffles.data.map((item) => (
                  <SelectItem key={item.id} value={item.id}>
                    {item.title} · {item.total_numbers} números
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="manual-status">Situação</Label>
            <Select
              value={status}
              onValueChange={(value) => {
                if (value === "paid" || value === "reserved") setStatus(value);
              }}
            >
              <SelectTrigger id="manual-status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="reserved">Reservado / aguardando pagamento</SelectItem>
                <SelectItem value="paid">Pago</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="manual-name">Nome do comprador</Label>
            <Input
              id="manual-name"
              autoComplete="name"
              placeholder="Nome completo"
              maxLength={160}
              value={buyerName}
              onChange={(event) => setBuyerName(event.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="manual-phone">Telefone (opcional)</Label>
            <Input
              id="manual-phone"
              type="tel"
              autoComplete="tel"
              placeholder="(00) 00000-0000"
              maxLength={30}
              value={buyerPhone}
              onChange={(event) => setBuyerPhone(event.target.value)}
            />
          </div>
          <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground lg:col-span-2">
            <Badge variant="outline">{raffle?.total_numbers ?? 0} números na rifa</Badge>
            <Badge variant="outline">
              {rows.filter((row) => row.status === "free").length} livres
            </Badge>
            <span>{selected.size} selecionados (máximo 500 por inclusão)</span>
          </div>
          <Button
            type="button"
            variant="gold"
            disabled={
              !canAdd ||
              addBuyer.isPending ||
              ticketsQuery.isLoading ||
              ticketsQuery.isError ||
              !!nameError ||
              !!selectionError
            }
            onClick={() => addBuyer.mutate()}
            className="lg:justify-self-end"
          >
            <UserPlus />{" "}
            {addBuyer.isPending
              ? "Adicionando…"
              : status === "paid"
                ? "Adicionar como pago"
                : "Adicionar como reservado"}
          </Button>
        </div>
        {!canAdd && raffle && (
          <p role="status" className="text-sm text-muted-foreground">
            {drawLocked
              ? "O resultado já foi publicado; não é possível alterar números."
              : "Esta rifa não está ativa e não aceita novos números."}
          </p>
        )}
        {selected.size > 0 && selected.size <= 500 && nameError && (
          <p role="status" className="text-sm text-destructive">
            {nameError}
          </p>
        )}
      </section>

      <section className="min-w-0 space-y-4 rounded-2xl border border-border bg-card p-4 sm:p-5">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative min-w-48 flex-1 sm:max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              aria-label="Buscar número ou comprador"
              placeholder="Buscar número ou comprador"
              className="pl-9"
              value={search}
              onChange={(event) => {
                setSearch(event.target.value);
                setPage(0);
              }}
            />
          </div>
          <Select
            value={filter}
            onValueChange={(value) => {
              setFilter(value);
              setPage(0);
            }}
          >
            <SelectTrigger aria-label="Filtrar números" className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os números</SelectItem>
              <SelectItem value="free">Livres</SelectItem>
              <SelectItem value="reserved">Reservados</SelectItem>
              <SelectItem value="paid">Pagos</SelectItem>
            </SelectContent>
          </Select>
          {selected.size > 0 && (
            <Button type="button" variant="ghost" size="sm" onClick={() => setSelected(new Set())}>
              <X /> Limpar seleção
            </Button>
          )}
        </div>

        {ticketsQuery.isLoading ? (
          <Skeleton className="h-56 rounded-xl" />
        ) : ticketsQuery.isError ? (
          <p role="alert" className="text-sm text-destructive">
            Não foi possível carregar os números desta rifa.
          </p>
        ) : (
          <>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        aria-label="Selecionar números livres desta página"
                        disabled={!canAdd || addBuyer.isPending || freeVisible.length === 0}
                        checked={
                          pageSelected
                            ? true
                            : freeVisible.some((row) => selected.has(row.number))
                              ? "indeterminate"
                              : false
                        }
                        onCheckedChange={() =>
                          setSelected((previous) => {
                            const next = new Set(previous);
                            for (const row of freeVisible) {
                              if (pageSelected) next.delete(row.number);
                              else if (next.size < 500) next.add(row.number);
                            }
                            return next;
                          })
                        }
                      />
                    </TableHead>
                    <TableHead>Número</TableHead>
                    <TableHead>Situação</TableHead>
                    <TableHead>Comprador</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visible.map((row) => (
                    <TableRow
                      key={row.number}
                      data-state={selected.has(row.number) ? "selected" : undefined}
                    >
                      <TableCell>
                        <Checkbox
                          aria-label={`Selecionar número ${row.number}`}
                          checked={selected.has(row.number)}
                          disabled={!canAdd || addBuyer.isPending || row.status !== "free"}
                          onCheckedChange={() => toggle(row.number)}
                        />
                      </TableCell>
                      <TableCell className="font-mono font-semibold">
                        {formatNumber(row.number, raffle!.total_numbers)}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            row.status === "paid"
                              ? "default"
                              : row.status === "reserved"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {row.status === "paid"
                            ? "Pago"
                            : row.status === "reserved"
                              ? "Reservado"
                              : "Livre"}
                        </Badge>
                      </TableCell>
                      <TableCell className="min-w-40 break-words">
                        {row.buyerName || (row.ticket ? "Comprador cadastrado" : "—")}
                      </TableCell>
                    </TableRow>
                  ))}
                  {visible.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={4} className="py-8 text-center text-muted-foreground">
                        Nenhum número encontrado.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center justify-between border-t border-border pt-3">
              <span className="text-sm text-muted-foreground">
                Página {currentPage + 1} de {pageCount} · {filtered.length} números
              </span>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  aria-label="Página anterior"
                  disabled={currentPage === 0}
                  onClick={() => setPage(currentPage - 1)}
                >
                  <ChevronLeft />
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  aria-label="Próxima página"
                  disabled={currentPage >= pageCount - 1}
                  onClick={() => setPage(currentPage + 1)}
                >
                  <ChevronRight />
                </Button>
              </div>
            </div>
          </>
        )}
      </section>
      <p className="flex items-center gap-2 text-xs text-muted-foreground">
        <Check className="size-3.5" /> Reserva ou venda é registrada na mesma tabela da rifa,
        impedindo a compra duplicada inclusive se houver duas tentativas simultâneas.
      </p>
    </div>
  );
}
