import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, Check, ExternalLink, Gift, Mail, MessageCircle, Phone, Trash2, Trophy, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RaffleForm } from "@/components/site/raffle-form";
import { RaffleWheel } from "@/components/site/raffle-wheel";
import { AdminNumbersTable } from "@/components/site/admin-numbers-table";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { adminPrizesQuery, adminTicketsQuery, raffleQuery, type AdminTicket } from "@/lib/queries";
import { errorMessage, formatBRL, formatNumber, formatPhone, STATUS_LABEL, whatsappLink, type Raffle } from "@/lib/raffle";
import { drawValidationError } from "@/lib/raffle-draw";

export const Route = createFileRoute("/_authenticated/admin/rifa/$id")({
  head: () => ({
    meta: [
      { title: "Gerenciar rifa — Admin Roleta Do Relison" },
      { name: "description", content: "Compradores, pagamentos, cotas premiadas e sorteio da rifa." },
      { property: "og:title", content: "Gerenciar rifa — Admin" },
      { property: "og:description", content: "Gerencie compradores e prêmios da rifa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ManageRaffle,
});

function ManageRaffle() {
  const { id } = Route.useParams();
  const raffleQ = useQuery(raffleQuery(id));
  const ticketsQ = useQuery(adminTicketsQuery(id));
  const prizesQ = useQuery(adminPrizesQuery(id));

  const raffle = raffleQ.data;
  const tickets = ticketsQ.data ?? [];
  const byNumber = useMemo(() => new Map(tickets.map((t) => [t.number, t])), [tickets]);

  if (raffleQ.isLoading) return <Skeleton className="h-96 rounded-3xl" />;
  if (!raffle) return <p>Rifa não encontrada.</p>;

  const paidCount = tickets.filter((t) => t.status === "paid").length;
  const reservedCount = tickets.length - paidCount;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button asChild variant="ghost" size="icon" aria-label="Voltar"><Link to="/admin"><ArrowLeft /></Link></Button>
          <div>
            <h2 className="font-display text-2xl font-bold">{raffle.title}</h2>
            <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
              <Badge variant={raffle.status === "active" ? "default" : "secondary"}>{STATUS_LABEL[raffle.status]}</Badge>
              <span>{raffle.total_numbers} cotas · {formatBRL(Number(raffle.price))}</span>
            </div>
          </div>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link to="/rifa/$id" params={{ id }}><ExternalLink /> Ver página pública</Link>
        </Button>
      </div>

      <div className="grid gap-3 sm:grid-cols-4">
        <Stat label="Pagas" value={String(paidCount)} />
        <Stat label="Aguardando pagamento" value={String(reservedCount)} />
        <Stat label="Livres" value={String(raffle.total_numbers - tickets.length)} />
        <Stat label="Arrecadado (pago)" value={formatBRL(paidCount * Number(raffle.price))} />
      </div>

      <Tabs defaultValue="numbers">
        <TabsList className="flex-wrap">
          <TabsTrigger value="numbers">Todas as cotas</TabsTrigger>
          <TabsTrigger value="buyers">Compradores</TabsTrigger>
          <TabsTrigger value="prizes">Cotas premiadas</TabsTrigger>
          <TabsTrigger value="draw">Sorteio</TabsTrigger>
          <TabsTrigger value="edit">Editar rifa</TabsTrigger>
        </TabsList>
        <TabsContent value="numbers" className="mt-4">
          <AdminNumbersTable raffle={raffle} tickets={tickets} loading={ticketsQ.isLoading} />
        </TabsContent>
        <TabsContent value="buyers" className="mt-4">
          <Buyers raffle={raffle} tickets={tickets} loading={ticketsQ.isLoading} />
        </TabsContent>
        <TabsContent value="prizes" className="mt-4">
          <Prizes raffle={raffle} prizes={prizesQ.data ?? []} byNumber={byNumber} />
        </TabsContent>
        <TabsContent value="draw" className="mt-4">
          <Draw raffle={raffle} byNumber={byNumber} tickets={tickets} />
        </TabsContent>
        <TabsContent value="edit" className="mt-4">
          <EditRaffle raffle={raffle} soldCount={tickets.length} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-display text-2xl font-bold">{value}</div>
    </div>
  );
}

function ContactLine({ t, raffle, extra }: { t: AdminTicket; raffle: Raffle; extra?: string }) {
  const p = t.profiles;
  const fullName = p?.full_name || t.manual_buyer_name || "Comprador sem cadastro";
  const phone = p?.phone || t.manual_buyer_phone;
  return (
    <div className="space-y-1 text-sm">
      <div className="font-semibold">{fullName}</div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 text-muted-foreground">
        {p?.email && <a href={`mailto:${p.email}`} className="flex items-center gap-1 hover:text-foreground"><Mail className="size-3.5" /> {p.email}</a>}
        {phone && (
          <a
            href={whatsappLink(phone, `Olá ${fullName.split(" ")[0]}! Aqui é da rifa "${raffle.title}". ${extra ?? ""}`)}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 hover:text-foreground"
          >
            <Phone className="size-3.5" /> {formatPhone(phone)}
          </a>
        )}
      </div>
    </div>
  );
}

function Buyers({ raffle, tickets, loading }: { raffle: Raffle; tickets: AdminTicket[]; loading: boolean }) {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [onlyPending, setOnlyPending] = useState(false);

  const groups = useMemo(() => {
    const m = new Map<string, AdminTicket[]>();
    for (const t of tickets) {
      const key = t.user_id
        ? `user:${t.user_id}`
        : `manual:${(t.manual_buyer_name ?? "").toLocaleLowerCase("pt-BR")}:${(t.manual_buyer_phone ?? "").replace(/\D/g, "")}`;
      m.set(key, [...(m.get(key) ?? []), t]);
    }
    return [...m.values()];
  }, [tickets]);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["admin-tickets", raffle.id] });
    qc.invalidateQueries({ queryKey: ["raffle-taken", raffle.id] });
    qc.invalidateQueries({ queryKey: ["raffles-progress"] });
  };

  const confirmPaid = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await supabase.from("tickets").update({ status: "paid", paid_at: new Date().toISOString() }).in("id", ids);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Pagamento confirmado!"); refresh(); },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const release = useMutation({
    mutationFn: async (ids: string[]) => {
      const { error } = await supabase.from("tickets").delete().in("id", ids);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Números liberados."); refresh(); },
    onError: (e) => toast.error(errorMessage(e)),
  });

  const term = q.trim().toLowerCase();
  const filtered = groups.filter((g) => {
    const p = g[0]?.profiles;
    if (onlyPending && !g.some((t) => t.status === "reserved")) return false;
    if (!term) return true;
    return (
      p?.full_name.toLowerCase().includes(term) ||
      p?.email.toLowerCase().includes(term) ||
      p?.phone.replace(/\D/g, "").includes(term.replace(/\D/g, "") || "§") ||
      g.some((t) => t.manual_buyer_name?.toLowerCase().includes(term) || t.manual_buyer_phone?.replace(/\D/g, "").includes(term.replace(/\D/g, "") || "§")) ||
      g.some((t) => formatNumber(t.number, raffle.total_numbers) === term || String(t.number) === term)
    );
  });

  if (loading) return <Skeleton className="h-60 rounded-2xl" />;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Input className="max-w-xs" placeholder="Buscar nome, e-mail, telefone ou número" value={q} onChange={(e) => setQ(e.target.value)} />
        <Button variant={onlyPending ? "default" : "outline"} size="sm" onClick={() => setOnlyPending((v) => !v)}>
          Só aguardando pagamento
        </Button>
      </div>
      {filtered.length === 0 && <p className="text-sm text-muted-foreground">Nenhum comprador encontrado.</p>}
      {filtered.map((g) => {
        const first = g[0];
        if (!first) return null;
        const reserved = g.filter((t) => t.status === "reserved");
        return (
          <div key={first.user_id ?? `${first.manual_buyer_name}:${first.manual_buyer_phone}`} className="rounded-2xl border border-border bg-card p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <ContactLine t={first} raffle={raffle} />
              <div className="flex flex-wrap gap-2">
                {reserved.length > 0 && (
                  <>
                    <Button size="sm" disabled={confirmPaid.isPending} onClick={() => confirmPaid.mutate(reserved.map((t) => t.id))}>
                      <Check /> Confirmar pagamento ({formatBRL(reserved.length * Number(raffle.price))})
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={release.isPending}
                      onClick={() => confirm("Liberar os números reservados deste comprador?") && release.mutate(reserved.map((t) => t.id))}
                    >
                      <X /> Liberar reservas
                    </Button>
                  </>
                )}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {g.map((t) => (
                <span key={t.id} className="num-cell px-2.5" data-state={t.status === "paid" ? "paid" : "reserved"} title={t.status === "paid" ? "Pago" : "Reservado"}>
                  {formatNumber(t.number, raffle.total_numbers)}
                </span>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Prizes({
  raffle,
  prizes,
  byNumber,
}: {
  raffle: Raffle;
  prizes: { id: string; number: number; prize: string }[];
  byNumber: Map<number, AdminTicket>;
}) {
  const qc = useQueryClient();
  const [num, setNum] = useState("");
  const [prize, setPrize] = useState("");

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["admin-prizes", raffle.id] });
    qc.invalidateQueries({ queryKey: ["raffle-prizes-public", raffle.id] });
  };

  const add = useMutation({
    mutationFn: async () => {
      const n = parseInt(num, 10);
      if (!Number.isFinite(n) || n < 1 || n > raffle.total_numbers) throw new Error(`Escolha um número entre 1 e ${raffle.total_numbers}.`);
      if (!prize.trim()) throw new Error("Descreva o prêmio.");
      const { error } = await supabase.from("raffle_prizes").insert({ raffle_id: raffle.id, number: n, prize: prize.trim() });
      if (error) throw error.code === "23505" ? new Error("Esse número já é uma cota premiada.") : error;
    },
    onSuccess: () => { toast.success("Cota premiada adicionada!"); setNum(""); setPrize(""); refresh(); },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const remove = useMutation({
    mutationFn: async (pid: string) => {
      const { error } = await supabase.from("raffle_prizes").delete().eq("id", pid);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Cota premiada removida."); refresh(); },
    onError: (e) => toast.error(errorMessage(e)),
  });

  return (
    <div className="space-y-5">
      <form
        onSubmit={(e) => { e.preventDefault(); add.mutate(); }}
        className="grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-[140px_1fr_auto] sm:items-end"
      >
        <div className="space-y-1.5">
          <Label htmlFor="pz-num">Número</Label>
          <Input id="pz-num" inputMode="numeric" placeholder="567" value={num} onChange={(e) => setNum(e.target.value.replace(/\D/g, ""))} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="pz-prize">Prêmio</Label>
          <Input id="pz-prize" placeholder="Ex.: R$ 200 no PIX" value={prize} onChange={(e) => setPrize(e.target.value)} />
        </div>
        <Button type="submit" variant="gold" disabled={add.isPending}><Gift /> Adicionar cota premiada</Button>
      </form>
      <p className="text-sm text-muted-foreground">
        Os números das cotas premiadas ficam escondidos do público. Só aparecem depois que alguém compra e o pagamento é confirmado.
      </p>

      <div className="grid gap-3">
        {prizes.length === 0 && <p className="text-sm text-muted-foreground">Nenhuma cota premiada ainda.</p>}
        {prizes.map((p) => {
          const t = byNumber.get(p.number);
          return (
            <div key={p.id} className="flex flex-wrap items-center gap-4 rounded-2xl border border-border bg-card p-4">
              <span className="grid size-14 place-items-center rounded-xl bg-gradient-gold font-display text-lg font-bold text-gold-foreground">
                {formatNumber(p.number, raffle.total_numbers)}
              </span>
              <div className="min-w-0 flex-1 space-y-1">
                <div className="font-semibold">{p.prize}</div>
                {!t && <Badge variant="outline">Ainda disponível</Badge>}
                {t && (
                  <div className="space-y-2">
                    <Badge variant={t.status === "paid" ? "default" : "secondary"}>
                      {t.status === "paid" ? "Ganhador confirmado (pago)" : "Reservado — aguardando pagamento"}
                    </Badge>
                    <ContactLine t={t} raffle={raffle} extra={`Parabéns! Seu número ${formatNumber(p.number, raffle.total_numbers)} é uma cota premiada: ${p.prize}.`} />
                  </div>
                )}
              </div>
              <Button
                variant="ghost"
                size="icon"
                aria-label="Remover cota premiada"
                onClick={() => confirm("Remover esta cota premiada?") && remove.mutate(p.id)}
              >
                <Trash2 />
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function Draw({ raffle, byNumber, tickets }: { raffle: Raffle; byNumber: Map<number, AdminTicket>; tickets: AdminTicket[] }) {
  const qc = useQueryClient();
  const [wheelBusy, setWheelBusy] = useState(false);
  const places = [
    { place: 1, label: "1º lugar", prize: raffle.prize, field: "winning_number" as const },
    { place: 2, label: "2º lugar", prize: raffle.prize_2, field: "winning_number_2" as const },
    { place: 3, label: "3º lugar", prize: raffle.prize_3, field: "winning_number_3" as const },
  ];
  const [nums, setNums] = useState<Record<number, string>>({
    1: raffle.winning_number != null ? String(raffle.winning_number) : "",
    2: raffle.winning_number_2 != null ? String(raffle.winning_number_2) : "",
    3: raffle.winning_number_3 != null ? String(raffle.winning_number_3) : "",
  });
  const parsed = places.map((p) => ({ ...p, n: Number.parseInt(nums[p.place] ?? "", 10), required: p.place === 1 || !!p.prize.trim() }));
  const paidCount = tickets.filter((t) => t.status === "paid").length;
  const soldOut = paidCount === raffle.total_numbers;
  const validationError = drawValidationError(raffle.total_numbers, tickets, parsed);
  const hasResult = raffle.winning_number != null || raffle.winning_number_2 != null || raffle.winning_number_3 != null;

  const save = useMutation({
    mutationFn: async (clear: boolean) => {
      if (!clear && validationError) throw new Error(validationError);
      const patch: Database["public"]["Tables"]["raffles"]["Update"] = {};
      for (const p of parsed) {
        if (!clear && Number.isFinite(p.n)) {
          if (p.n < 1 || p.n > raffle.total_numbers) throw new Error(`Número entre 1 e ${raffle.total_numbers}.`);
          patch[p.field] = p.n;
        } else {
          patch[p.field] = null;
        }
      }
      if (!clear) patch["status"] = "finished";
      const { error } = await supabase.from("raffles").update(patch).eq("id", raffle.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Sorteio atualizado!");
      qc.invalidateQueries({ queryKey: ["raffle", raffle.id] });
      qc.invalidateQueries({ queryKey: ["raffle-winner", raffle.id] });
      qc.invalidateQueries({ queryKey: ["raffles"] });
      qc.invalidateQueries({ queryKey: ["my-tickets"] });
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <div className="min-w-0 space-y-5">
        <RaffleWheel
          raffleId={raffle.id}
          total={raffle.total_numbers}
          disabled={!soldOut || save.isPending}
          numbers={nums}
          onPicked={(place, number) => setNums((s) => ({ ...s, [place]: String(number) }))}
          onBusyChange={setWheelBusy}
        />
        <h3 className="text-lg font-bold">Números sorteados</h3>
        {!soldOut && <p role="status" className="text-sm text-muted-foreground">Sorteio aguardando todas as cotas pagas: {paidCount} de {raffle.total_numbers}.</p>}
        <div className="grid gap-3">
          {parsed.map((p) => {
            const preview = Number.isFinite(p.n) ? byNumber.get(p.n) : undefined;
            return (
              <div key={p.place} className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <Label htmlFor={`draw-place-${p.place}`} className="min-w-0 flex-1 break-words text-sm font-medium">
                    {p.label}{p.prize ? ` — ${p.prize}` : ""}
                  </Label>
                  <Input
                    id={`draw-place-${p.place}`}
                    className="w-32 shrink-0"
                    inputMode="numeric"
                    disabled={!soldOut || save.isPending || wheelBusy}
                    maxLength={String(raffle.total_numbers).length}
                    value={nums[p.place] ?? ""}
                    onChange={(e) => setNums((s) => ({ ...s, [p.place]: e.target.value.replace(/\D/g, "") }))}
                    placeholder="Número"
                  />
                </div>
                {Number.isFinite(p.n) && (
                  <div className="rounded-xl bg-muted p-3 text-sm">
                    {preview ? (
                      <>
                        <div className="mb-1 font-medium">
                          Dono do número {formatNumber(p.n, raffle.total_numbers)} ({preview.status === "paid" ? "pago" : "reservado, não pago"}):
                        </div>
                        <ContactLine t={preview} raffle={raffle} />
                      </>
                    ) : (
                      <span>Ninguém comprou o número {formatNumber(p.n, raffle.total_numbers)}.</span>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
        {soldOut && validationError && <p role="status" className="text-sm text-destructive">{validationError}</p>}
        <div className="flex flex-wrap gap-2">
          <Button variant="gold" disabled={!!validationError || save.isPending || wheelBusy} onClick={() => save.mutate(false)}>
            <Trophy /> Salvar resultado
          </Button>
          {hasResult && (
            <Button variant="ghost" disabled={wheelBusy || save.isPending} onClick={() => { setNums({ 1: "", 2: "", 3: "" }); save.mutate(true); }}>Apagar resultado</Button>
          )}
        </div>
      </div>

      <div className="rounded-2xl bg-gradient-ink p-5 text-ink-foreground">
        <div className="text-xs uppercase tracking-widest text-ink-foreground/70">Resultado publicado</div>
        {!hasResult ? (
          <p className="mt-2 text-ink-foreground/80">Ainda não houve sorteio.</p>
        ) : (
          <div className="mt-2 space-y-5">
            {places.map((p) => {
              const value = raffle[p.field];
              if (value == null) return null;
              const saved = byNumber.get(value);
              return (
                <div key={p.place} className="space-y-2">
                  <div className="text-xs uppercase tracking-widest text-ink-foreground/70">
                    {p.label}{p.prize ? ` — ${p.prize}` : ""}
                  </div>
                  <div className="font-display text-4xl font-extrabold text-gold">{formatNumber(value, raffle.total_numbers)}</div>
                  {saved && (saved.profiles || saved.manual_buyer_name) ? (
                    <div className="space-y-1 text-sm">
                      <div className="text-lg font-semibold">{saved.profiles?.full_name || saved.manual_buyer_name}</div>
                      {saved.profiles?.email && <div>{saved.profiles.email}</div>}
                      {(saved.profiles?.phone || saved.manual_buyer_phone) && <div>{formatPhone(saved.profiles?.phone || saved.manual_buyer_phone!)}</div>}
                      {(saved.profiles?.phone || saved.manual_buyer_phone) && (
                        <Button asChild variant="gold" size="sm" className="mt-2">
                          <a
                            href={whatsappLink(saved.profiles?.phone || saved.manual_buyer_phone!, `Parabéns ${(saved.profiles?.full_name || saved.manual_buyer_name || "").split(" ")[0]}! Seu número ${formatNumber(value, raffle.total_numbers)} foi sorteado em ${p.label} na rifa "${raffle.title}"!`)}
                            target="_blank"
                            rel="noreferrer"
                          >
                            <MessageCircle /> Avisar no WhatsApp
                          </a>
                        </Button>
                      )}
                    </div>
                  ) : (
                    <p className="text-ink-foreground/80">Esse número não foi vendido.</p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function EditRaffle({ raffle, soldCount }: { raffle: Raffle; soldCount: number }) {
  const qc = useQueryClient();
  const navigate = useNavigate();
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-border bg-card p-5">
        <RaffleForm
          initial={raffle}
          soldCount={soldCount}
          submitLabel="Salvar alterações"
          onSubmit={async (v) => {
            const { error } = await supabase.from("raffles").update(v).eq("id", raffle.id);
            if (error) {
              toast.error(errorMessage(error));
              return;
            }
            toast.success("Rifa atualizada!");
            qc.invalidateQueries({ queryKey: ["raffle", raffle.id] });
            qc.invalidateQueries({ queryKey: ["raffles"] });
          }}
        />
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-destructive/40 p-4">
        <span className="text-sm">Excluir a rifa apaga também todas as cotas e compradores dela.</span>
        <Button
          variant="destructive"
          onClick={async () => {
            if (!confirm(`Excluir a rifa "${raffle.title}"? Isso não pode ser desfeito.`)) return;
            const { error } = await supabase.from("raffles").delete().eq("id", raffle.id);
            if (error) { toast.error(errorMessage(error)); return; }
            toast.success("Rifa excluída.");
            qc.invalidateQueries({ queryKey: ["raffles"] });
            navigate({ to: "/admin" });
          }}
        >
          <Trash2 /> Excluir rifa
        </Button>
      </div>
    </div>
  );
}
