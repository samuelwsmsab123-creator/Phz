import { createFileRoute, Link, Outlet, redirect } from "@tanstack/react-router";
import { Settings, Ticket, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin")({
  beforeLoad: async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) throw redirect({ to: "/auth" });
    const { data } = await supabase.rpc("has_role", { _user_id: u.user.id, _role: "admin" });
    if (!data) throw redirect({ to: "/" });
  },
  component: AdminLayout,
});

function AdminLayout() {
  const linkCls =
    "flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-muted-foreground hover:bg-muted";
  const activeCls = "bg-secondary text-secondary-foreground";
  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <div className="text-xs font-semibold uppercase tracking-widest text-primary">
            Painel do administrador
          </div>
          <h1 className="text-3xl font-extrabold">Gerenciar rifas</h1>
        </div>
        <nav className="flex flex-wrap gap-1 rounded-xl border border-border bg-card p-1">
          <Link
            to="/admin"
            activeOptions={{ exact: true }}
            className={linkCls}
            activeProps={{ className: activeCls }}
          >
            <Ticket className="size-4" /> Rifas
          </Link>
          <Link to="/admin/compradores" className={linkCls} activeProps={{ className: activeCls }}>
            <UserPlus className="size-4" /> Comprador manual
          </Link>
          <Link
            to="/admin/configuracoes"
            className={linkCls}
            activeProps={{ className: activeCls }}
          >
            <Settings className="size-4" /> PIX e contato
          </Link>
        </nav>
      </div>
      <Outlet />
    </div>
  );
}
