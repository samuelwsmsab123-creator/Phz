import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { RaffleForm } from "@/components/site/raffle-form";
import { RaffleImage } from "@/components/site/raffle-image";
import { supabase } from "@/integrations/supabase/client";
import { rafflesProgressQuery, rafflesQuery, settingsQuery } from "@/lib/queries";
import { errorMessage, formatBRL, formatDate, STATUS_LABEL } from "@/lib/raffle";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({
    meta: [
      { title: "Painel admin — Roleta Do Relison" },
      { name: "description", content: "Crie e gerencie rifas, cotas premiadas e pagamentos." },
      { property: "og:title", content: "Painel admin — Roleta Do Relison" },
      { property: "og:description", content: "Gerencie suas rifas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AdminHome,
});

function AdminHome() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const raffles = useQuery(rafflesQuery());
  const progress = useQuery(rafflesProgressQuery());
  const settings = useQuery(settingsQuery());
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-6">
      {settings.data && !settings.data.pix_key && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-warning bg-warning/15 p-4 text-sm">
          <span>Você ainda não configurou a chave PIX. Os compradores não saberão para onde pagar.</span>
          <Button asChild size="sm" variant="ink"><Link to="/admin/configuracoes">Configurar PIX</Link></Button>
        </div>
      )}

      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Suas rifas</h2>
        <Button variant="gold" onClick={() => setOpen(true)}><Plus /> Nova rifa</Button>
      </div>

      <div className="grid gap-4">
        {(raffles.data ?? []).map((r) => {
          const taken = progress.data?.[r.id] ?? 0;
          const pct = Math.round((taken / r.total_numbers) * 100);
          return (
            <Link
              key={r.id}
              to="/admin/rifa/$id"
              params={{ id: r.id }}
              className="flex flex-col gap-4 rounded-2xl border border-border bg-card p-4 shadow-ticket transition-colors hover:border-primary sm:flex-row sm:items-center"
            >
              <div className="h-24 w-full shrink-0 overflow-hidden rounded-xl sm:w-36">
                <RaffleImage path={r.image_url} alt={r.title} />
              </div>
              <div className="min-w-0 flex-1 space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-display text-lg font-bold">{r.title}</span>
                  <Badge variant={r.status === "active" ? "default" : "secondary"}>{STATUS_LABEL[r.status]}</Badge>
                </div>
                <div className="text-sm text-muted-foreground">
                  {r.total_numbers} cotas · {formatBRL(Number(r.price))} cada · Sorteio {formatDate(r.draw_date)}
                </div>
                <Progress value={pct} className="h-2" />
                <div className="text-xs text-muted-foreground">{taken} vendidas/reservadas ({pct}%)</div>
              </div>
            </Link>
          );
        })}
        {raffles.data?.length === 0 && (
          <div className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
            Nenhuma rifa ainda. Clique em "Nova rifa" para começar.
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Nova rifa</DialogTitle>
          </DialogHeader>
          <RaffleForm
            submitLabel="Criar rifa"
            onSubmit={async (v) => {
              const { data, error } = await supabase.from("raffles").insert(v).select("id").single();
              if (error) {
                toast.error(errorMessage(error));
                return;
              }
              toast.success("Rifa criada! Agora adicione as cotas premiadas.");
              setOpen(false);
              qc.invalidateQueries({ queryKey: ["raffles"] });
              navigate({ to: "/admin/rifa/$id", params: { id: data.id } });
            }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
