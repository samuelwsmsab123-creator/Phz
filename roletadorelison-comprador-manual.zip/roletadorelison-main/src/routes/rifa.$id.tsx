import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CalendarDays, Gift, Search, Shuffle, Sparkles, Trophy, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { RaffleImage } from "@/components/site/raffle-image";
import { PixDialog } from "@/components/site/pix-dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { myTicketsQuery, raffleQuery, rafflePrizesPublicQuery, raffleTakenQuery, raffleWinnerQuery } from "@/lib/queries";
import { errorMessage, formatBRL, formatDate, formatNumber, pickRandomNumbers, STATUS_LABEL } from "@/lib/raffle";

export const Route = createFileRoute("/rifa/$id")({
  head: () => ({
    meta: [
      { title: "Escolha seus números — Roleta Do Relison" },
      { name: "description", content: "Escolha seus números da sorte, veja as cotas premiadas e pague via PIX." },
      { property: "og:title", content: "Escolha seus números — Roleta Do Relison" },
      { property: "og:description", content: "Escolha seus números da sorte e concorra a prêmios." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RafflePage,
});

type Filter = "all" | "free" | "taken" | "mine";

function RafflePage() {
  const { id } = Route.useParams();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const raffleQ = useQuery(raffleQuery(id));
  const takenQ = useQuery(raffleTakenQuery(id));
  const prizesQ = useQuery(rafflePrizesPublicQuery(id));
  const winnerQ = useQuery(raffleWinnerQuery(id));
  const mineQ = useQuery({ ...myTicketsQuery(user?.id ?? ""), enabled: !!user });

  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [filter, setFilter] = useState<Filter>("all");
  const [find, setFind] = useState("");
  const [pix, setPix] = useState<{ amount: number; numbers: string[] } | null>(null);

  const raffle = raffleQ.data;
  const mine = useMemo(
    () => new Set((mineQ.data ?? []).filter((t) => t.raffle_id === id).map((t) => t.number)),
    [mineQ.data, id],
  );
  const myReserved = (mineQ.data ?? []).filter((t) => t.raffle_id === id && t.status === "reserved");
  const reserved = takenQ.data?.reserved ?? new Set<number>();
  const paid = takenQ.data?.paid ?? new Set<number>();
  const takenAll = useMemo(() => new Set([...reserved, ...paid]), [reserved, paid]);

  const reserve = useMutation({
    mutationFn: async (numbers: number[]) => {
      const { error } = await supabase.rpc("reserve_numbers", { _raffle_id: id, _numbers: numbers });
      if (error) throw error;
      return numbers;
    },
    onSuccess: (numbers) => {
      if (!raffle) return;
      setPix({
        amount: numbers.length * Number(raffle.price),
        numbers: numbers.map((n) => formatNumber(n, raffle.total_numbers)),
      });
      setSelected(new Set());
      toast.success("Números reservados!");
      qc.invalidateQueries({ queryKey: ["raffle-taken", id] });
      qc.invalidateQueries({ queryKey: ["my-tickets"] });
      qc.invalidateQueries({ queryKey: ["raffles-progress"] });
    },
    onError: (e) => {
      toast.error(errorMessage(e));
      qc.invalidateQueries({ queryKey: ["raffle-taken", id] });
    },
  });

  if (raffleQ.isLoading) {
    return (
      <div className="mx-auto max-w-6xl space-y-4 px-4 py-10">
        <Skeleton className="h-72 rounded-3xl" />
        <Skeleton className="h-96 rounded-3xl" />
      </div>
    );
  }
  if (!raffle) {
    return (
      <div className="mx-auto max-w-md px-4 py-20 text-center">
        <h1 className="text-2xl font-bold">Rifa não encontrada</h1>
        <Button asChild className="mt-6"><Link to="/">Ver rifas</Link></Button>
      </div>
    );
  }

  const total = raffle.total_numbers;
  const isOpen = raffle.status === "active";
  const pct = Math.min(100, Math.round((takenAll.size / total) * 100));
  const findNum = Number(find);

  const numbers: number[] = [];
  for (let n = 1; n <= total; n++) {
    if (find && !formatNumber(n, total).includes(find)) continue;
    const isTaken = takenAll.has(n);
    if (filter === "free" && isTaken) continue;
    if (filter === "taken" && !isTaken) continue;
    if (filter === "mine" && !mine.has(n)) continue;
    numbers.push(n);
  }

  function toggle(n: number) {
    if (!isOpen || takenAll.has(n)) return;
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(n)) next.delete(n);
      else next.add(n);
      return next;
    });
  }

  function quickPick(count: number) {
    const block = new Set([...takenAll, ...selected]);
    const picks = pickRandomNumbers(total, block, count);
    if (picks.length === 0) { toast.error("Não há mais números livres."); return; }
    setSelected((s) => new Set([...s, ...picks]));
  }

  function submit() {
    if (!user) {
      navigate({ to: "/auth", search: { redirect: `/rifa/${id}` } });
      return;
    }
    if (profile && profile.phone.replace(/\D/g, "").length < 10) {
      toast.error("Complete seu telefone no perfil antes de comprar.");
      navigate({ to: "/perfil" });
      return;
    }
    reserve.mutate([...selected].sort((a, b) => a - b));
  }

  const selectedTotal = selected.size * Number(raffle.price);

  return (
    <div className="pb-32">
      <section className="mx-auto grid max-w-6xl gap-8 px-4 py-8 lg:grid-cols-[1.1fr_1fr]">
        <div className="overflow-hidden rounded-3xl border border-border shadow-ticket">
          <div className="aspect-[4/3]">
            <RaffleImage path={raffle.image_url} alt={raffle.title} eager />
          </div>
        </div>
        <div className="flex flex-col gap-5">
          <div className="flex flex-wrap gap-2">
            <Badge variant={isOpen ? "default" : "secondary"}>{STATUS_LABEL[raffle.status] ?? raffle.status}</Badge>
            <Badge variant="outline" className="gap-1"><CalendarDays className="size-3" /> Sorteio: {formatDate(raffle.draw_date)}</Badge>
          </div>
          <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl">{raffle.title}</h1>
          {(raffle.prize || raffle.prize_2 || raffle.prize_3) && (
            <div className="space-y-2 rounded-2xl bg-accent p-4 text-accent-foreground">
              {[
                { place: "1º lugar", prize: raffle.prize },
                { place: "2º lugar", prize: raffle.prize_2 },
                { place: "3º lugar", prize: raffle.prize_3 },
              ]
                .filter((p) => p.prize)
                .map((p) => (
                  <div key={p.place} className="flex items-start gap-3">
                    <Gift className="mt-0.5 size-5 shrink-0" />
                    <div>
                      <div className="text-xs font-semibold uppercase tracking-widest">{p.place}</div>
                      <div className="font-semibold">{p.prize}</div>
                    </div>
                  </div>
                ))}
            </div>
          )}
          {raffle.description && <p className="whitespace-pre-line text-muted-foreground">{raffle.description}</p>}
          <div className="rounded-2xl border border-border bg-card p-4">
            <div className="flex items-baseline justify-between">
              <span className="font-display text-3xl font-extrabold text-primary">{formatBRL(Number(raffle.price))}</span>
              <span className="text-sm text-muted-foreground">por cota</span>
            </div>
            <Progress value={pct} className="mt-3 h-2.5" />
            <div className="mt-2 flex justify-between text-xs text-muted-foreground">
              <span>{takenAll.size} de {total} cotas vendidas</span>
              <span>{pct}%</span>
            </div>
          </div>
          {myReserved.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-warning bg-warning/15 p-4 text-sm">
              <span>
                Você tem <strong>{myReserved.length}</strong> {myReserved.length === 1 ? "número reservado" : "números reservados"} aguardando pagamento.
              </span>
              <Button
                size="sm"
                variant="ink"
                onClick={() =>
                  setPix({
                    amount: myReserved.length * Number(raffle.price),
                    numbers: myReserved.map((t) => formatNumber(t.number, total)),
                  })
                }
              >
                Ver PIX
              </Button>
            </div>
          )}
        </div>
      </section>

      {(winnerQ.data?.length ?? 0) > 0 && (
        <section className="mx-auto max-w-6xl px-4">
          <div className="grid gap-3 sm:grid-cols-3">
            {winnerQ.data!.map((w) => (
              <div key={w.place} className="flex flex-col gap-3 rounded-3xl bg-gradient-ink p-6 text-ink-foreground">
                <div className="flex items-center gap-3">
                  <Trophy className="size-8 text-gold" />
                  <div className="text-xs uppercase tracking-widest text-ink-foreground/70">
                    {w.place}º lugar{w.prize ? ` — ${w.prize}` : ""}
                  </div>
                </div>
                <div className="font-display text-3xl font-extrabold text-gold">{formatNumber(w.number, total)}</div>
                <div className="text-sm">
                  <span className="text-ink-foreground/70">Ganhador: </span>
                  <span className="font-semibold">{w.winner_name || "Número não vendido"}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {(prizesQ.data?.length ?? 0) > 0 && (
        <section className="mx-auto mt-8 max-w-6xl px-4">
          <h2 className="flex items-center gap-2 text-2xl font-extrabold">
            <Sparkles className="size-6 text-gold" /> Cotas premiadas
          </h2>
          <p className="text-sm text-muted-foreground">Números secretos com prêmio instantâneo. Quem comprar, ganha!</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {prizesQ.data!.map((p) => (
              <div
                key={p.id}
                className={
                  p.claimed
                    ? "flex items-center gap-3 rounded-2xl border border-border bg-muted p-4"
                    : "flex items-center gap-3 rounded-2xl border border-gold/50 bg-card p-4 shadow-ticket"
                }
              >
                <span className={p.claimed ? "grid size-12 place-items-center rounded-xl bg-primary font-display font-bold text-primary-foreground" : "grid size-12 place-items-center rounded-xl bg-gradient-gold font-display text-lg font-bold text-gold-foreground"}>
                  {p.claimed && p.number != null ? formatNumber(p.number, total) : "?"}
                </span>
                <div className="min-w-0">
                  <div className="truncate font-semibold">{p.prize}</div>
                  <div className="text-xs text-muted-foreground">
                    {p.claimed ? `Encontrada por ${p.winner_name || "um comprador"}` : "Ainda escondida — pode ser sua!"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="mx-auto mt-10 max-w-6xl px-4">
        <div className="rounded-3xl border border-border bg-card p-5 shadow-ticket sm:p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-extrabold">Escolha seus números</h2>
              <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                <Legend state="free" label="Livre" />
                <Legend state="selected" label="Selecionado" />
                <Legend state="reserved" label="Reservado" />
                <Legend state="paid" label="Pago" />
                {user && <Legend state="mine" label="Seu" />}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={find}
                  onChange={(e) => setFind(e.target.value.replace(/\D/g, ""))}
                  placeholder="Buscar número"
                  inputMode="numeric"
                  className="w-40 pl-8"
                />
              </div>
              <ToggleGroup type="single" value={filter} onValueChange={(v) => v && setFilter(v as Filter)} variant="outline" size="sm">
                <ToggleGroupItem value="all">Todos</ToggleGroupItem>
                <ToggleGroupItem value="free">Livres</ToggleGroupItem>
                <ToggleGroupItem value="taken">Vendidos</ToggleGroupItem>
                {user && <ToggleGroupItem value="mine">Meus</ToggleGroupItem>}
              </ToggleGroup>
            </div>
          </div>

          {isOpen && (
            <div className="mt-4 flex flex-wrap items-center gap-2 rounded-2xl bg-muted p-3">
              <span className="flex items-center gap-1.5 text-sm font-medium"><Shuffle className="size-4" /> Escolha rápida:</span>
              {[1, 5, 10, 25, 50].map((c) => (
                <Button key={c} size="sm" variant="outline" onClick={() => quickPick(c)}>+{c}</Button>
              ))}
              {selected.size > 0 && (
                <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
                  <X /> Limpar
                </Button>
              )}
            </div>
          )}

          {takenQ.isLoading ? (
            <Skeleton className="mt-5 h-80 rounded-2xl" />
          ) : (
            <div className="mt-5 grid max-h-[620px] grid-cols-[repeat(auto-fill,minmax(3.25rem,1fr))] gap-1.5 overflow-y-auto pr-1">
              {numbers.map((n) => {
                const state = mine.has(n)
                  ? "mine"
                  : paid.has(n)
                    ? "paid"
                    : reserved.has(n)
                      ? "reserved"
                      : selected.has(n)
                        ? "selected"
                        : "free";
                return (
                  <button
                    key={n}
                    type="button"
                    className="num-cell"
                    data-state={state}
                    disabled={!isOpen || state === "paid" || state === "reserved" || state === "mine"}
                    onClick={() => toggle(n)}
                    aria-pressed={state === "selected"}
                    aria-label={`Número ${formatNumber(n, total)}`}
                  >
                    {formatNumber(n, total)}
                  </button>
                );
              })}
              {numbers.length === 0 && (
                <p className="col-span-full py-10 text-center text-sm text-muted-foreground">
                  {find && findNum > total ? `Esta rifa vai até ${total}.` : "Nenhum número neste filtro."}
                </p>
              )}
            </div>
          )}
          {!isOpen && (
            <p className="mt-4 text-center text-sm text-muted-foreground">As vendas desta rifa estão encerradas.</p>
          )}
        </div>
      </section>

      {selected.size > 0 && (
        <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-card/95 backdrop-blur animate-rise">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4">
            <div className="min-w-0">
              <div className="text-sm text-muted-foreground">
                {selected.size} {selected.size === 1 ? "número selecionado" : "números selecionados"}
              </div>
              <div className="max-w-[60vw] truncate text-sm font-semibold">
                {[...selected].sort((a, b) => a - b).map((n) => formatNumber(n, total)).join(", ")}
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="font-display text-2xl font-extrabold text-primary">{formatBRL(selectedTotal)}</span>
              <Button variant="gold" size="xl" onClick={submit} disabled={reserve.isPending}>
                {reserve.isPending ? "Reservando..." : user ? "Reservar e pagar" : "Entrar para comprar"}
              </Button>
            </div>
          </div>
        </div>
      )}

      {pix && (
        <PixDialog
          open={!!pix}
          onOpenChange={(v) => !v && setPix(null)}
          amount={pix.amount}
          numbers={pix.numbers}
          raffleTitle={raffle.title}
        />
      )}
    </div>
  );
}

function Legend({ state, label }: { state: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <span className="num-cell size-4 !h-4 !rounded" data-state={state} />
      {label}
    </span>
  );
}
