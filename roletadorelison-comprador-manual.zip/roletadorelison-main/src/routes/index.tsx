import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { MousePointerClick, QrCode, Trophy } from "lucide-react";
import heroImg from "@/assets/hero-sorte.jpg";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RaffleCard } from "@/components/site/raffle-card";
import { rafflesProgressQuery, rafflesQuery } from "@/lib/queries";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Roleta Do Relison — Rifas digitais com PIX" },
      { name: "description", content: "Escolha seus números da sorte, pague via PIX e concorra a prêmios e cotas premiadas." },
      { property: "og:title", content: "Roleta Do Relison — Rifas digitais com PIX" },
      { property: "og:description", content: "Escolha seus números da sorte e concorra a prêmios e cotas premiadas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const raffles = useQuery(rafflesQuery());
  const progress = useQuery(rafflesProgressQuery());
  const list = raffles.data ?? [];
  const active = list.filter((r) => r.status === "active");
  const others = list.filter((r) => r.status !== "active");

  return (
    <>
      <section className="relative overflow-hidden bg-gradient-ink text-ink-foreground">
        <img
          src={heroImg}
          alt="Bolas douradas de sorteio e bilhetes de rifa"
          width={1600}
          height={912}
          className="absolute inset-0 h-full w-full object-cover object-right opacity-80"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/85 to-transparent" />
        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-28">
          <div className="max-w-xl animate-rise">
            <span className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-gold">
              <Trophy className="size-3.5" /> Cotas premiadas em cada rifa
            </span>
            <h1 className="mt-5 text-5xl font-extrabold leading-[1.02] sm:text-6xl">
              Escolha seu número.
              <br />
              <span className="text-gold">A sorte faz o resto.</span>
            </h1>
            <p className="mt-5 text-lg text-ink-foreground/80">
              Rifas digitais com escolha de números, pagamento via PIX e prêmios escondidos em cotas especiais.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="xl">
                <a href="#rifas">Ver rifas abertas</a>
              </Button>
              <Button asChild variant="outline-light" size="xl">
                <Link to="/auth" search={{ mode: "signup" }}>Criar minha conta</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-12 sm:grid-cols-3">
        {[
          { icon: MousePointerClick, title: "1. Escolha", text: "Toque nos números livres da rifa ou use a escolha rápida." },
          { icon: QrCode, title: "2. Pague via PIX", text: "Reserve e pague com a chave PIX mostrada na tela." },
          { icon: Trophy, title: "3. Concorra", text: "Após a confirmação, seus números valem no sorteio e nas cotas premiadas." },
        ].map((s) => (
          <div key={s.title} className="flex gap-4 rounded-2xl border border-border bg-card p-5">
            <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-secondary text-primary">
              <s.icon className="size-5" />
            </span>
            <div>
              <h3 className="font-bold">{s.title}</h3>
              <p className="text-sm text-muted-foreground">{s.text}</p>
            </div>
          </div>
        ))}
      </section>

      <section id="rifas" className="mx-auto max-w-6xl scroll-mt-20 px-4">
        <h2 className="text-3xl font-extrabold sm:text-4xl">Rifas abertas</h2>
        <p className="mt-1 text-muted-foreground">Garanta seus números antes que acabem.</p>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {raffles.isLoading &&
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="aspect-[4/5] rounded-2xl" />)}
          {active.map((r) => (
            <RaffleCard key={r.id} raffle={r} taken={progress.data?.[r.id] ?? 0} />
          ))}
        </div>
        {!raffles.isLoading && active.length === 0 && (
          <div className="mt-6 rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
            Nenhuma rifa aberta no momento. Volte em breve!
          </div>
        )}

        {others.length > 0 && (
          <>
            <h2 className="mt-16 text-2xl font-extrabold">Rifas encerradas</h2>
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {others.map((r) => (
                <RaffleCard key={r.id} raffle={r} taken={progress.data?.[r.id] ?? 0} />
              ))}
            </div>
          </>
        )}
      </section>
    </>
  );
}
