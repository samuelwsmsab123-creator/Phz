import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { MailCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { errorMessage, formatPhone, onlyDigits } from "@/lib/raffle";

type Search = { mode?: "signin" | "signup"; redirect?: string };

function safeRedirect(r: string | undefined) {
  return r && r.startsWith("/") && !r.startsWith("//") ? r : "/";
}

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ...(s["mode"] === "signup" || s["mode"] === "signin" ? { mode: s["mode"] } : {}),
    ...(typeof s["redirect"] === "string" ? { redirect: s["redirect"] } : {}),
  }),
  head: () => ({
    meta: [
      { title: "Entrar ou criar conta — Roleta Do Relison" },
      { name: "description", content: "Acesse sua conta Roleta Do Relison para escolher números e acompanhar suas cotas." },
      { property: "og:title", content: "Entrar — Roleta Do Relison" },
      { property: "og:description", content: "Acesse sua conta para participar das rifas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [tab, setTab] = useState<string>(search.mode ?? "signin");
  const [busy, setBusy] = useState(false);
  const [sentTo, setSentTo] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", password: "" });
  const redirectTo = safeRedirect(search.redirect);

  useEffect(() => {
    if (user) navigate({ to: redirectTo });
  }, [user, navigate, redirectTo]);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: k === "phone" ? formatPhone(e.target.value) : e.target.value }));

  async function signIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email: form.email.trim(), password: form.password });
    setBusy(false);
    if (error) toast.error(error.message === "Invalid login credentials" ? "E-mail ou senha incorretos." : error.message);
  }

  async function signUp(e: React.FormEvent) {
    e.preventDefault();
    if (form.name.trim().split(/\s+/).length < 2) { toast.error("Informe seu nome completo."); return; }
    if (onlyDigits(form.phone).length < 10) { toast.error("Informe um telefone com DDD."); return; }
    if (form.password.length < 6) { toast.error("A senha precisa ter pelo menos 6 caracteres."); return; }
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email: form.email.trim(),
      password: form.password,
      options: {
        emailRedirectTo: window.location.origin + redirectTo,
        data: { full_name: form.name.trim(), phone: form.phone },
      },
    });
    setBusy(false);
    if (error) { toast.error(errorMessage(error)); return; }
    if (!data.session) setSentTo(form.email.trim());
  }

  async function forgot() {
    if (!form.email.trim()) { toast.error("Digite seu e-mail no campo acima."); return; }
    const { error } = await supabase.auth.resetPasswordForEmail(form.email.trim(), {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) toast.error(errorMessage(error));
    else toast.success("Enviamos um link para redefinir sua senha.");
  }

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-14">
      <div className="rounded-3xl border border-border bg-card p-7 shadow-ticket">
        {sentTo ? (
          <div className="py-6 text-center">
            <MailCheck className="mx-auto size-12 text-primary" />
            <h1 className="mt-4 text-2xl font-bold">Confirme seu e-mail</h1>
            <p className="mt-2 text-muted-foreground">
              Enviamos um link para <strong className="text-foreground">{sentTo}</strong>. Clique nele para ativar sua conta.
            </p>
            <Button variant="outline" className="mt-6" onClick={() => { setSentTo(null); setTab("signin"); }}>
              Voltar para entrar
            </Button>
          </div>
        ) : (
          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="signin">Entrar</TabsTrigger>
              <TabsTrigger value="signup">Criar conta</TabsTrigger>
            </TabsList>

            <TabsContent value="signin">
              <form onSubmit={signIn} className="mt-5 space-y-4">
                <h1 className="text-2xl font-bold">Bem-vindo de volta</h1>
                <Field label="E-mail" id="si-email">
                  <Input id="si-email" type="email" required value={form.email} onChange={set("email")} autoComplete="email" />
                </Field>
                <Field label="Senha" id="si-pass">
                  <Input id="si-pass" type="password" required value={form.password} onChange={set("password")} autoComplete="current-password" />
                </Field>
                <Button type="submit" className="w-full" size="lg" disabled={busy}>
                  {busy ? "Entrando..." : "Entrar"}
                </Button>
                <button type="button" onClick={forgot} className="w-full text-center text-sm text-muted-foreground underline-offset-4 hover:underline">
                  Esqueci minha senha
                </button>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={signUp} className="mt-5 space-y-4">
                <h1 className="text-2xl font-bold">Crie sua conta</h1>
                <p className="-mt-2 text-sm text-muted-foreground">Usamos seus dados para avisar se você ganhar.</p>
                <Field label="Nome completo" id="su-name">
                  <Input id="su-name" required value={form.name} onChange={set("name")} autoComplete="name" />
                </Field>
                <Field label="E-mail" id="su-email">
                  <Input id="su-email" type="email" required value={form.email} onChange={set("email")} autoComplete="email" />
                </Field>
                <Field label="Telefone / WhatsApp" id="su-phone">
                  <Input id="su-phone" required inputMode="tel" placeholder="(11) 91234-5678" value={form.phone} onChange={set("phone")} autoComplete="tel" />
                </Field>
                <Field label="Senha" id="su-pass">
                  <Input id="su-pass" type="password" required minLength={6} value={form.password} onChange={set("password")} autoComplete="new-password" />
                </Field>
                <Button type="submit" className="w-full" size="lg" disabled={busy}>
                  {busy ? "Criando..." : "Criar conta"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </div>
  );
}

function Field({ label, id, children }: { label: string; id: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}
