import { describe, expect, it } from "vitest";
import { numberRows, selectionError } from "@/lib/admin-numbers";

const tickets = [
  { number: 1, status: "paid", user_id: "ana", profiles: { full_name: "Ana Silva" } },
  { number: 5, status: "reserved", user_id: "pedro", profiles: { full_name: "Pedro Santos" } },
];

describe("tabela administrativa de cotas", () => {
  it("inclui todos os números, livres e ocupados, com nome e pagamento", () => {
    const rows = numberRows(859, tickets);
    expect(rows).toHaveLength(859);
    expect(rows[0]).toMatchObject({ number: 1, status: "paid", buyerName: "Ana Silva" });
    expect(rows[4]).toMatchObject({ number: 5, status: "reserved", buyerName: "Pedro Santos" });
    expect(rows[858]).toMatchObject({ number: 859, status: "free", buyerName: "" });
  });
  it("mostra compradores sem perfil de login como titulares dos números", () => {
    const rows = numberRows(850, [
      {
        number: 850,
        status: "reserved",
        user_id: null,
        manual_buyer_name: "Maria Oliveira",
        profiles: null,
      },
    ]);
    expect(rows).toHaveLength(850);
    expect(rows[849]).toMatchObject({
      number: 850,
      status: "reserved",
      buyerName: "Maria Oliveira",
    });
  });
  it("exige comprador para reservar ou pagar uma cota livre", () => {
    expect(selectionError([2], tickets, "")).not.toBeNull();
    expect(selectionError([2], tickets, "ana")).toBeNull();
  });
  it("permite selecionar cotas de vários compradores mantendo seus nomes", () => {
    expect(selectionError([1, 5], tickets, "")).toBeNull();
  });
  it("não troca o titular de uma cota já vendida", () => {
    expect(selectionError([5], tickets, "ana")).not.toBeNull();
    expect(selectionError([5, 2], tickets, "pedro")).toBeNull();
  });
  it("limita alterações a 500 cotas", () => {
    expect(
      selectionError(
        Array.from({ length: 500 }, (_, i) => i + 1),
        [],
        "ana",
      ),
    ).toBeNull();
    expect(
      selectionError(
        Array.from({ length: 501 }, (_, i) => i + 1),
        [],
        "ana",
      ),
    ).not.toBeNull();
  });
});
