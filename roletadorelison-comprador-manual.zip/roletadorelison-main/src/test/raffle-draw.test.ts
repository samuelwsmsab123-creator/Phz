import { describe, expect, it } from "vitest";
import { drawValidationError } from "@/lib/raffle-draw";

const paid = Array.from({ length: 9 }, (_, i) => ({ number: i + 1, status: "paid" }));
const places = [1, 5, 9].map((n) => ({ n, required: true }));

describe("sorteio por lugar", () => {
  it("só permite sortear após todas as cotas pagas, não apenas reservadas", () => {
    expect(drawValidationError(9, paid.slice(0, 8), places)).toContain("todas as cotas");
    expect(drawValidationError(9, [...paid.slice(0, 8), { number: 9, status: "reserved" }], places)).toContain("todas as cotas");
    expect(drawValidationError(9, paid, places)).toBeNull();
  });
  it("aceita um número por lugar: primeiro 1, segundo 5 e terceiro 9", () => {
    expect(drawValidationError(9, paid, places)).toBeNull();
  });
  it("não permite o mesmo número em dois lugares", () => {
    expect(drawValidationError(9, paid, [1, 5, 5].map((n) => ({ n, required: true })))).toContain("diferente");
  });
  it("exige um número para cada lugar com prêmio", () => {
    expect(drawValidationError(9, paid, [{ n: 1, required: true }, { n: NaN, required: true }])).toContain("cada lugar");
  });
});