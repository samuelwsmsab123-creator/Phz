import { describe, expect, it } from "vitest";
import { formatNumber, pickRandomNumbers } from "@/lib/raffle";

describe("raffle numbers", () => {
  it("pads numbers to the width of the total (850 cotas -> 3 digits)", () => {
    expect(formatNumber(7, 850)).toBe("007");
    expect(formatNumber(567, 859)).toBe("567");
  });

  it("quick pick never returns taken numbers and stays within 1..total", () => {
    const taken = new Set([1, 2, 3, 4]);
    const picks = pickRandomNumbers(5, taken, 10);
    expect(picks).toEqual([5]);
  });
});
