declare module "spin-wheel" {
  export class Wheel {
    constructor(container: HTMLElement, props: {
      items: { label: string; weight?: number }[];
      isInteractive: boolean;
      pointerAngle: number;
      radius: number;
      borderColor: string;
      borderWidth: number;
      lineColor: string;
      lineWidth: number;
      itemBackgroundColors: string[];
      itemLabelColors: string[];
      itemLabelFont: string;
      itemLabelFontSizeMax: number;
      itemLabelRadius: number;
      itemLabelRadiusMax: number;
    });
    onRest: (() => void) | null;
    spinToItem(index: number, duration: number, spinToCenter: boolean, revolutions: number, direction: number): void;
    remove(): void;
  }
}