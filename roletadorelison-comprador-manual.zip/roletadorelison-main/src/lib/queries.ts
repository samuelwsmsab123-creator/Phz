import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const rafflesQuery = () =>
  queryOptions({
    queryKey: ["raffles"],
    queryFn: async () => {
      const { data, error } = await supabase.from("raffles").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export const rafflesProgressQuery = () =>
  queryOptions({
    queryKey: ["raffles-progress"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_raffles_progress");
      if (error) throw error;
      const map: Record<string, number> = {};
      for (const row of data ?? []) map[row.raffle_id] = row.taken;
      return map;
    },
  });

export const raffleQuery = (id: string) =>
  queryOptions({
    queryKey: ["raffle", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("raffles").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const raffleTakenQuery = (id: string) =>
  queryOptions({
    queryKey: ["raffle-taken", id],
    refetchInterval: 15000,
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_raffle_taken", { _raffle_id: id });
      if (error) throw error;
      const json = (data ?? {}) as { reserved?: number[]; paid?: number[] };
      return { reserved: new Set(json.reserved ?? []), paid: new Set(json.paid ?? []) };
    },
  });

export const rafflePrizesPublicQuery = (id: string) =>
  queryOptions({
    queryKey: ["raffle-prizes-public", id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_raffle_prizes_public", { _raffle_id: id });
      if (error) throw error;
      return data ?? [];
    },
  });

export const raffleWinnerQuery = (id: string) =>
  queryOptions({
    queryKey: ["raffle-winner", id],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_raffle_winner", { _raffle_id: id });
      if (error) throw error;
      return data ?? [];
    },
  });

export const settingsQuery = () =>
  queryOptions({
    queryKey: ["site-settings"],
    queryFn: async () => {
      const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
      if (error) throw error;
      return data ?? { id: 1, pix_key: "", pix_holder: "", contact_phone: "", updated_at: "" };
    },
  });

export const myTicketsQuery = (userId: string) =>
  queryOptions({
    queryKey: ["my-tickets", userId],
    queryFn: async () => {
      const rows: Array<{
        id: string;
        number: number;
        status: string;
        created_at: string;
        raffle_id: string;
        raffles: { id: string; title: string; total_numbers: number; price: number; status: string; winning_number: number | null; winning_number_2: number | null; winning_number_3: number | null } | null;
      }> = [];
      for (let from = 0; ; from += 1000) {
        const { data, error } = await supabase
          .from("tickets")
          .select("id, number, status, created_at, raffle_id, raffles(id, title, total_numbers, price, status, winning_number, winning_number_2, winning_number_3)")
          .eq("user_id", userId)
          .order("number")
          .range(from, from + 999);
        if (error) throw error;
        rows.push(...(data ?? []));
        if (!data || data.length < 1000) break;
      }
      return rows;
    },
  });

export const myPrizesQuery = (userId: string) =>
  queryOptions({
    queryKey: ["my-prizes", userId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("get_my_prizes");
      if (error) throw error;
      return data ?? [];
    },
  });

export const profileQuery = (userId: string) =>
  queryOptions({
    queryKey: ["profile", userId],
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const isAdminQuery = (userId: string) =>
  queryOptions({
    queryKey: ["is-admin", userId],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("has_role", { _user_id: userId, _role: "admin" });
      if (error) throw error;
      return Boolean(data);
    },
  });

export type AdminTicket = {
  id: string;
  number: number;
  status: string;
  created_at: string;
  paid_at: string | null;
  user_id: string | null;
  manual_buyer_name: string | null;
  manual_buyer_phone: string | null;
  profiles: { full_name: string; email: string; phone: string } | null;
};

export const adminBuyersQuery = () =>
  queryOptions({
    queryKey: ["admin-buyers"],
    queryFn: async () => {
      const rows: Array<{ id: string; full_name: string; email: string; phone: string }> = [];
      for (let from = 0; ; from += 1000) {
        const { data, error } = await supabase.from("profiles")
          .select("id, full_name, email, phone").order("full_name").order("id").range(from, from + 999);
        if (error) throw error;
        rows.push(...(data ?? []));
        if (!data || data.length < 1000) break;
      }
      return rows;
    },
  });

export const adminTicketsQuery = (raffleId: string) =>
  queryOptions({
    queryKey: ["admin-tickets", raffleId],
    queryFn: async () => {
      const rows: AdminTicket[] = [];
      for (let from = 0; ; from += 1000) {
        const { data, error } = await supabase
          .from("tickets")
          .select("id, number, status, created_at, paid_at, user_id, manual_buyer_name, manual_buyer_phone, profiles(full_name, email, phone)")
          .eq("raffle_id", raffleId)
          .order("number")
          .range(from, from + 999);
        if (error) throw error;
        rows.push(...((data ?? []) as AdminTicket[]));
        if (!data || data.length < 1000) break;
      }
      return rows;
    },
  });

export const adminPrizesQuery = (raffleId: string) =>
  queryOptions({
    queryKey: ["admin-prizes", raffleId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("raffle_prizes")
        .select("*")
        .eq("raffle_id", raffleId)
        .order("number");
      if (error) throw error;
      return data;
    },
  });
