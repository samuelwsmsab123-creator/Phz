import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const spinRaffleNumber = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(z.object({ raffleId: z.string().uuid(), excluded: z.array(z.number().int().positive()).max(2) }))
  .handler(async ({ data, context }) => {
    const { data: admin, error: roleError } = await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" });
    if (roleError || !admin) throw new Error("Somente o administrador pode sortear.");
    const { data: raffle, error } = await context.supabase.from("raffles").select("total_numbers").eq("id", data.raffleId).single();
    if (error || !raffle) throw new Error("Rifa não encontrada.");
    const { count, error: countError } = await context.supabase.from("tickets").select("id", { count: "exact", head: true }).eq("raffle_id", data.raffleId).eq("status", "paid");
    if (countError || count !== raffle.total_numbers) throw new Error("Aguarde o pagamento de todas as cotas para sortear.");
    const pool = Array.from({ length: raffle.total_numbers }, (_, i) => i + 1).filter((n) => !data.excluded.includes(n));
    if (!pool.length) throw new Error("Não há outro número disponível para este lugar.");
    const limit = Math.floor(4294967296 / pool.length) * pool.length;
    const random = new Uint32Array(1);
    let value = limit;
    while (value >= limit) {
      crypto.getRandomValues(random);
      value = random[0] ?? limit;
    }
    const number = pool[value % pool.length];
    if (number === undefined) throw new Error("Não foi possível sortear. Tente novamente.");
    return number;
  });