export type NumberTicket = {
  number: number;
  status: string;
  user_id: string | null;
  manual_buyer_name?: string | null;
  profiles: { full_name: string } | null;
};

export function numberRows<T extends NumberTicket>(total: number, tickets: readonly T[]) {
  const byNumber = new Map(tickets.map((ticket) => [ticket.number, ticket]));
  return Array.from({ length: total }, (_, index) => {
    const number = index + 1;
    const ticket = byNumber.get(number);
    return {
      number,
      ticket,
      status: ticket?.status ?? "free",
      buyerName: ticket?.profiles?.full_name || ticket?.manual_buyer_name || "",
    };
  });
}

export function selectionError(numbers: readonly number[], tickets: readonly NumberTicket[], buyerId: string): string | null {
  if (numbers.length === 0) return "Selecione pelo menos uma cota.";
  if (numbers.length > 500) return "Selecione no máximo 500 cotas por alteração.";
  const byNumber = new Map(tickets.map((ticket) => [ticket.number, ticket]));
  if (numbers.some((number) => !byNumber.has(number)) && !buyerId) return "Escolha o comprador das cotas livres.";
  if (buyerId && numbers.some((number) => {
    const ticket = byNumber.get(number);
    return ticket && ticket.user_id !== buyerId;
  })) return "A seleção contém cotas de outro comprador. Mantenha os compradores atuais ou selecione apenas cotas desse comprador.";
  return null;
}
