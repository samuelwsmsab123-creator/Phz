import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const pathSchema = z
  .string()
  .min(1)
  .max(200)
  .regex(/^[a-zA-Z0-9][a-zA-Z0-9._/-]*$/, "Caminho inválido.")
  .refine((p) => !p.includes(".."), "Caminho inválido.");

// Signed URLs are minted server-side so the storage bucket needs no public read policy.
export const getRaffleImageUrl = createServerFn({ method: "GET" })
  .inputValidator(pathSchema)
  .handler(async ({ data: path }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin.storage
      .from("raffle-images")
      .createSignedUrl(path, 60 * 60);
    if (error || !data?.signedUrl) throw new Error("Imagem não encontrada.");
    return data.signedUrl;
  });
