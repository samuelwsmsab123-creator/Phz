export function drawValidationError(
  total: number,
  tickets: readonly { number: number; status: string }[],
  places: readonly { n: number; required: boolean }[],
): string | null {
  const paid = new Set(tickets.filter((t) => t.status === "paid").map((t) => t.number));
  if (paid.size !== total) return "O sorteio só pode ser publicado quando todas as cotas estiverem pagas.";
  if (places.some((p) => p.required && !Number.isFinite(p.n))) return "Informe um número para cada lugar com prêmio.";
  const numbers = places.filter((p) => Number.isFinite(p.n)).map((p) => p.n);
  if (numbers.some((n) => !Number.isInteger(n) || n < 1 || n > total)) return `Escolha números entre 1 e ${total}.`;
  if (new Set(numbers).size !== numbers.length) return "Escolha um número diferente para cada lugar.";
  if (numbers.some((n) => !paid.has(n))) return "O número sorteado precisa estar pago.";
  return null;
}