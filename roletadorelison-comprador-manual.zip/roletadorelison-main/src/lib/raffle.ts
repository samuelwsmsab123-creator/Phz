import type { Database } from "@/integrations/supabase/types";

export type Raffle = Database["public"]["Tables"]["raffles"]["Row"];
export type RaffleStatus = "active" | "closed" | "finished";

export const SITE_NAME = "Roleta Do Relison";

export function formatNumber(n: number, total: number): string {
  return String(n).padStart(String(total).length, "0");
}

export function formatBRL(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "A definir";
  return new Date(iso).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export const STATUS_LABEL: Record<string, string> = {
  active: "Vendas abertas",
  closed: "Vendas encerradas",
  finished: "Sorteada",
};

export function onlyDigits(v: string): string {
  return v.replace(/\D/g, "");
}

export function formatPhone(v: string): string {
  const d = onlyDigits(v).slice(0, 11);
  if (d.length <= 2) return d.length ? `(${d}` : "";
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

export function whatsappLink(phone: string, message: string): string {
  let d = onlyDigits(phone);
  if (d.length <= 11) d = `55${d}`;
  return `https://wa.me/${d}?text=${encodeURIComponent(message)}`;
}

/** Picks `count` random available numbers between 1 and total, skipping taken ones. */
export function pickRandomNumbers(total: number, taken: Set<number>, count: number): number[] {
  const free: number[] = [];
  for (let i = 1; i <= total; i++) if (!taken.has(i)) free.push(i);
  for (let i = free.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = free[i]!;
    free[i] = free[j]!;
    free[j] = a;
  }
  return free.slice(0, Math.min(count, free.length)).sort((a, b) => a - b);
}

export function errorMessage(err: unknown): string {
  if (err && typeof err === "object" && "message" in err) return String((err as { message: unknown }).message);
  return "Algo deu errado. Tente novamente.";
}
