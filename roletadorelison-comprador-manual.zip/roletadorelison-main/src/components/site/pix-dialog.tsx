import { useQuery } from "@tanstack/react-query";
import { Copy, MessageCircle, QrCode } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { settingsQuery } from "@/lib/queries";
import { formatBRL, whatsappLink } from "@/lib/raffle";

export function PixDialog({
  open,
  onOpenChange,
  amount,
  numbers,
  raffleTitle,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  amount: number;
  numbers: string[];
  raffleTitle: string;
}) {
  const settings = useQuery(settingsQuery());
  const s = settings.data;
  const message = `Olá! Paguei ${formatBRL(amount)} da rifa "${raffleTitle}". Meus números: ${numbers.join(", ")}. Segue o comprovante.`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-2xl">
            <QrCode className="size-6 text-primary" /> Pague via PIX
          </DialogTitle>
          <DialogDescription>
            Seus números estão reservados. Faça o PIX e envie o comprovante para confirmar.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-2xl bg-gradient-ink p-5 text-ink-foreground">
            <div className="text-xs uppercase tracking-widest text-ink-foreground/70">Valor a pagar</div>
            <div className="font-display text-4xl font-extrabold text-gold">{formatBRL(amount)}</div>
            <div className="mt-2 text-sm text-ink-foreground/80">
              {numbers.length} {numbers.length === 1 ? "número" : "números"}: {numbers.slice(0, 20).join(", ")}
              {numbers.length > 20 ? "…" : ""}
            </div>
          </div>

          {s?.pix_key ? (
            <div className="space-y-2">
              <div className="text-sm font-medium">Chave PIX</div>
              <div className="flex items-center gap-2 rounded-xl border border-border bg-muted p-3">
                <code className="flex-1 break-all text-sm">{s.pix_key}</code>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    navigator.clipboard.writeText(s.pix_key);
                    toast.success("Chave PIX copiada!");
                  }}
                >
                  <Copy /> Copiar
                </Button>
              </div>
              {s.pix_holder && <p className="text-sm text-muted-foreground">Titular: {s.pix_holder}</p>}
            </div>
          ) : (
            <p className="rounded-xl bg-accent p-3 text-sm text-accent-foreground">
              A chave PIX ainda não foi configurada pelo organizador.
            </p>
          )}

          {s?.contact_phone && (
            <Button asChild variant="gold" className="w-full" size="lg">
              <a href={whatsappLink(s.contact_phone, message)} target="_blank" rel="noreferrer">
                <MessageCircle /> Enviar comprovante no WhatsApp
              </a>
            </Button>
          )}
          <p className="text-center text-xs text-muted-foreground">
            Após a confirmação do pagamento, seus números aparecem como pagos em "Minhas cotas".
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
