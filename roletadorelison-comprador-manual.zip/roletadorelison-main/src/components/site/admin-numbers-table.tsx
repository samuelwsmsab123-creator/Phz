import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Save, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { adminBuyersQuery, type AdminTicket } from "@/lib/queries";
import { numberRows, selectionError } from "@/lib/admin-numbers";
import { errorMessage, formatNumber, type Raffle } from "@/lib/raffle";

const PAGE_SIZE = 100;

export function AdminNumbersTable({ raffle, tickets, loading }: { raffle: Raffle; tickets: AdminTicket[]; loading: boolean }) {
  const qc = useQueryClient();
  const buyers = useQuery(adminBuyersQuery());
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [buyerId, setBuyerId] = useState("");
  const [buyerSearch, setBuyerSearch] = useState("");
  const [status, setStatus] = useState<"paid" | "reserved">("reserved");
  const locked = raffle.winning_number != null || raffle.winning_number_2 != null || raffle.winning_number_3 != null;
  const rows = useMemo(() => numberRows(raffle.total_numbers, tickets), [raffle.total_numbers, tickets]);
  const term = search.trim().toLocaleLowerCase("pt-BR");
  const filtered = rows.filter((row) => (filter === "all" || row.status === filter) && (!term ||
    row.buyerName.toLocaleLowerCase("pt-BR").includes(term) || String(row.number) === term || formatNumber(row.number, raffle.total_numbers) === term));
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, pages - 1);
  const visible = filtered.slice(currentPage * PAGE_SIZE, (currentPage + 1) * PAGE_SIZE);
  const pageSelected = visible.length > 0 && visible.every((row) => selected.has(row.number));
  const matchingBuyers = (buyers.data ?? []).filter((buyer) => !buyerSearch.trim() ||
    `${buyer.full_name} ${buyer.email} ${buyer.phone}`.toLocaleLowerCase("pt-BR").includes(buyerSearch.trim().toLocaleLowerCase("pt-BR")));
  const chosenBuyer = buyers.data?.find((buyer) => buyer.id === buyerId);
  const buyerOptions = matchingBuyers.slice(0, 50);
  if (chosenBuyer && !buyerOptions.some((buyer) => buyer.id === chosenBuyer.id)) buyerOptions.unshift(chosenBuyer);
  const validation = selectionError([...selected], tickets, buyerId);

  const save = useMutation({
    mutationFn: async () => {
      if (validation) throw new Error(validation);
      const { error } = await supabase.rpc("admin_manage_numbers", {
        _raffle_id: raffle.id, _numbers: [...selected].sort((a, b) => a - b),
        ...(buyerId ? { _buyer_id: buyerId } : {}), _status: status,
      });
      if (error) throw error;
    },
    onSuccess: async () => {
      toast.success("Cotas atualizadas!");
      setSelected(new Set());
      await Promise.all(["admin-tickets", "raffle-taken", "raffles-progress", "my-tickets", "my-prizes", "raffle-prizes-public", "admin-prizes"].map((key) =>
        qc.invalidateQueries({ queryKey: [key] })));
    },
    onError: (error) => toast.error(errorMessage(error)),
  });

  function toggle(number: number) {
    setSelected((previous) => {
      const next = new Set(previous);
      if (next.has(number)) next.delete(number); else next.add(number);
      return next;
    });
  }

  if (loading) return <Skeleton className="h-60 rounded-lg" />;

  return (
    <div className="min-w-0 space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <Input aria-label="Buscar cota ou comprador" placeholder="Buscar número ou nome do comprador" className="max-w-sm" value={search} onChange={(event) => { setSearch(event.target.value); setPage(0); }} />
        <Select value={filter} onValueChange={(value) => { setFilter(value); setPage(0); }}>
          <SelectTrigger aria-label="Filtrar situação" className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todas as cotas</SelectItem><SelectItem value="free">Livres</SelectItem><SelectItem value="reserved">Reservadas</SelectItem><SelectItem value="paid">Pagas</SelectItem></SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">{filtered.length} cotas · {selected.size} selecionadas</span>
        {selected.size > 0 && <Button variant="ghost" size="sm" disabled={save.isPending} onClick={() => setSelected(new Set())}><X /> Limpar seleção</Button>}
      </div>
      {locked && <p role="status" className="text-sm text-muted-foreground">Resultado publicado: as cotas não podem ser alteradas.</p>}
      <form className="grid gap-3 border-y border-border py-4 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_160px_auto] lg:items-end" onSubmit={(event) => { event.preventDefault(); save.mutate(); }}>
        <div className="min-w-0 space-y-1.5"><Label htmlFor="buyer-search">Nome do comprador</Label><Input id="buyer-search" placeholder="Buscar comprador cadastrado" value={buyerSearch} onChange={(event) => setBuyerSearch(event.target.value)} disabled={locked || save.isPending} /></div>
        <div className="min-w-0 space-y-1.5"><Label htmlFor="number-buyer">Comprador</Label>
          <Select value={buyerId || "keep"} onValueChange={(value) => setBuyerId(value === "keep" ? "" : value)} disabled={locked || save.isPending || buyers.isLoading}>
            <SelectTrigger id="number-buyer"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="keep">Manter compradores atuais</SelectItem>{buyerOptions.map((buyer) => <SelectItem key={buyer.id} value={buyer.id}>{buyer.full_name || "Sem nome"} — {buyer.email}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5"><Label htmlFor="number-status">Situação</Label>
          <Select value={status} onValueChange={(value) => { if (value === "paid" || value === "reserved") setStatus(value); }} disabled={locked || save.isPending}>
            <SelectTrigger id="number-status"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="reserved">Reservado</SelectItem><SelectItem value="paid">Pago</SelectItem></SelectContent>
          </Select>
        </div>
        <Button type="submit" disabled={locked || save.isPending || !!validation}><Save />{save.isPending ? "Salvando…" : "Salvar cotas"}</Button>
        {selected.size > 0 && validation && <p role="status" className="text-sm text-destructive sm:col-span-2 lg:col-span-4">{validation}</p>}
        {buyers.isError && <p role="alert" className="text-sm text-destructive sm:col-span-2 lg:col-span-4">Não foi possível carregar os compradores.</p>}
      </form>
      <Table>
        <TableHeader><TableRow>
          <TableHead className="w-12"><Checkbox aria-label="Selecionar cotas desta página" disabled={locked || save.isPending || visible.length === 0} checked={pageSelected ? true : visible.some((row) => selected.has(row.number)) ? "indeterminate" : false} onCheckedChange={() => setSelected((previous) => { const next = new Set(previous); for (const row of visible) { if (pageSelected) next.delete(row.number); else next.add(row.number); } return next; })} /></TableHead>
          <TableHead>Número</TableHead><TableHead>Situação</TableHead><TableHead>Comprador</TableHead>
        </TableRow></TableHeader>
        <TableBody>{visible.map((row) => <TableRow key={row.number} data-state={selected.has(row.number) ? "selected" : undefined}>
          <TableCell><Checkbox aria-label={`Selecionar cota ${row.number}`} checked={selected.has(row.number)} disabled={locked || save.isPending} onCheckedChange={() => toggle(row.number)} /></TableCell>
          <TableCell className="font-mono font-semibold">{formatNumber(row.number, raffle.total_numbers)}</TableCell>
          <TableCell><Badge variant={row.status === "paid" ? "default" : row.status === "reserved" ? "secondary" : "outline"}>{row.status === "paid" ? "Pago" : row.status === "reserved" ? "Reservado" : "Livre"}</Badge></TableCell>
          <TableCell className="min-w-40 break-words">{row.buyerName || (row.ticket ? "Sem nome" : "—")}</TableCell>
        </TableRow>)}{visible.length === 0 && <TableRow><TableCell colSpan={4} className="py-8 text-center text-muted-foreground">Nenhuma cota encontrada.</TableCell></TableRow>}</TableBody>
      </Table>
      <div className="flex items-center justify-between border-t border-border pt-3">
        <span className="text-sm text-muted-foreground">Página {currentPage + 1} de {pages}</span>
        <div className="flex gap-2"><Button variant="outline" size="icon" aria-label="Página anterior" disabled={currentPage === 0} onClick={() => setPage(currentPage - 1)}><ChevronLeft /></Button><Button variant="outline" size="icon" aria-label="Próxima página" disabled={currentPage >= pages - 1} onClick={() => setPage(currentPage + 1)}><ChevronRight /></Button></div>
      </div>
    </div>
  );
}