import { useQuery } from "@tanstack/react-query";
import { getRaffleImageUrl } from "@/lib/raffle-image.functions";
import defaultImg from "@/assets/raffle-default.jpg";
import { cn } from "@/lib/utils";

export function useRaffleImageUrl(path: string | null | undefined) {
  const { data } = useQuery({
    queryKey: ["raffle-image", path],
    enabled: !!path && !path.startsWith("http"),
    staleTime: 50 * 60 * 1000,
    queryFn: () => {
      if (!path) throw new Error("Foto não selecionada.");
      return getRaffleImageUrl({ data: path });
    },
  });
  if (!path) return defaultImg;
  if (path.startsWith("http")) return path;
  return data ?? defaultImg;
}

export function RaffleImage({ path, alt, className, eager }: { path: string | null | undefined; alt: string; className?: string; eager?: boolean }) {
  const src = useRaffleImageUrl(path);
  return (
    <img
      src={src}
      alt={alt}
      loading={eager ? "eager" : "lazy"}
      width={1200}
      height={900}
      className={cn("h-full w-full object-cover", className)}
    />
  );
}
