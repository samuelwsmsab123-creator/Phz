import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ChevronDown, RotateCw } from "lucide-react";
import { toast } from "sonner";
import type { Wheel } from "spin-wheel";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { spinRaffleNumber } from "@/lib/raffle-spin.functions";
import { errorMessage, formatNumber } from "@/lib/raffle";

export function RaffleWheel({ raffleId, total, disabled, numbers, onPicked, onBusyChange }: {
  raffleId: string;
  total: number;
  disabled: boolean;
  numbers: Record<number, string>;
  onPicked: (place: number, number: number) => void;
  onBusyChange: (busy: boolean) => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const wheel = useRef<Wheel | null>(null);
  const spinning = useRef(false);
  const alive = useRef(true);
  const [ready, setReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const [place, setPlace] = useState("1");
  const [result, setResult] = useState<{ place: number; number: number } | null>(null);
  const spin = useServerFn(spinRaffleNumber);
  const groupSize = Math.ceil(total / 20);

  useEffect(() => {
    alive.current = true;
    let cancelled = false;
    async function mount() {
      const { Wheel: SpinWheel } = await import("spin-wheel");
      const container = host.current;
      if (!container || cancelled) return;
      const theme = getComputedStyle(container);
      const token = (name: string) => theme.getPropertyValue(name).trim();
      const items = Array.from({ length: Math.ceil(total / groupSize) }, (_, i) => {
        const first = i * groupSize + 1;
        const last = Math.min(total, first + groupSize - 1);
        return { label: first === last ? formatNumber(first, total) : `${formatNumber(first, total)}–${formatNumber(last, total)}`, weight: last - first + 1 };
      });
      wheel.current = new SpinWheel(container, {
        items, isInteractive: false, pointerAngle: 270, radius: 0.94,
        borderColor: token("--gold"), borderWidth: 5,
        lineColor: token("--background"), lineWidth: 1,
        itemBackgroundColors: [token("--primary"), token("--gold")],
        itemLabelColors: [token("--primary-foreground"), token("--gold-foreground")],
        itemLabelFont: theme.fontFamily, itemLabelFontSizeMax: 22,
        itemLabelRadius: 0.89, itemLabelRadiusMax: 0.38,
      });
      setReady(true);
    }
    void mount().catch((e) => toast.error(errorMessage(e)));
    return () => {
      cancelled = true;
      alive.current = false;
      wheel.current?.remove();
      wheel.current = null;
    };
  }, [total, groupSize]);

  async function startSpin() {
    if (!wheel.current || disabled || spinning.current) return;
    spinning.current = true;
    setBusy(true);
    onBusyChange(true);
    setResult(null);
    const targetPlace = Number(place);
    try {
      const excluded = Object.entries(numbers).filter(([key]) => Number(key) !== targetPlace).map(([, value]) => Number.parseInt(value, 10)).filter(Number.isFinite);
      const number = await spin({ data: { raffleId, excluded } });
      const currentWheel = wheel.current;
      if (!alive.current || !currentWheel) return;
      currentWheel.onRest = () => {
        currentWheel.onRest = null;
        if (!alive.current) return;
        setResult({ place: targetPlace, number });
        onPicked(targetPlace, number);
        spinning.current = false;
        setBusy(false);
        onBusyChange(false);
      };
      const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      currentWheel.spinToItem(Math.floor((number - 1) / groupSize), reduced ? 1 : 4800, true, reduced ? 0 : 5, 1);
    } catch (e) {
      if (!alive.current) return;
      spinning.current = false;
      setBusy(false);
      onBusyChange(false);
      toast.error(errorMessage(e));
    }
  }

  return (
    <section className="space-y-4" aria-label="Roleta de números">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-display text-xl font-bold">Roleta do sorteio</h3>
        <div className="flex items-center gap-2">
          <Label htmlFor="wheel-place">Lugar</Label>
          <Select value={place} onValueChange={setPlace} disabled={busy}>
            <SelectTrigger id="wheel-place" className="w-28"><SelectValue /></SelectTrigger>
            <SelectContent>{[1, 2, 3].map((p) => <SelectItem key={p} value={String(p)}>{p}º lugar</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <div className="relative mx-auto aspect-square w-full max-w-sm">
        <div ref={host} className="absolute inset-0" aria-hidden="true" />
        <ChevronDown className="absolute left-1/2 top-0 z-10 size-10 -translate-x-1/2 fill-gold text-gold-foreground" aria-hidden="true" />
        <div className="pointer-events-none absolute left-1/2 top-1/2 grid size-24 -translate-x-1/2 -translate-y-1/2 place-content-center rounded-full border-4 border-gold bg-background text-center" role="status" aria-live="polite">
          <span className="font-display text-3xl font-bold tabular-nums">{result ? formatNumber(result.number, total) : busy ? "…" : "—"}</span>
          <span className="text-xs text-muted-foreground">{result ? `${result.place}º lugar` : busy ? "Sorteando" : "Roleta"}</span>
        </div>
      </div>
      <Button type="button" variant="gold" size="lg" className="w-full" disabled={disabled || !ready || busy} onClick={() => void startSpin()}>
        <RotateCw className={busy ? "animate-spin motion-reduce:animate-none" : ""} /> {busy ? "Sorteando…" : `Girar para o ${place}º lugar`}
      </Button>
    </section>
  );
}