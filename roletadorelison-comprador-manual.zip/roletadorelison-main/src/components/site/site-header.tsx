import { Link, useNavigate } from "@tanstack/react-router";
import { Ticket, LogOut, Shield, User as UserIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { SITE_NAME } from "@/lib/raffle";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2">
      <span className="grid size-9 place-items-center rounded-full bg-gradient-gold font-display text-lg font-bold text-gold-foreground shadow-glow">
        7
      </span>
      <span className="font-display text-xl font-bold tracking-tight">{SITE_NAME}</span>
    </Link>
  );
}

export function SiteHeader() {
  const { user, isAdmin } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
        <Logo />
        <nav className="flex items-center gap-1 sm:gap-2">
          {user ? (
            <>
              <Button asChild variant="ghost" size="sm">
                <Link to="/minhas-cotas">
                  <Ticket /> <span className="hidden sm:inline">Minhas cotas</span>
                </Link>
              </Button>
              <Button asChild variant="ghost" size="sm">
                <Link to="/perfil">
                  <UserIcon /> <span className="hidden sm:inline">Perfil</span>
                </Link>
              </Button>
              {isAdmin && (
                <Button asChild variant="gold" size="sm">
                  <Link to="/admin">
                    <Shield /> <span className="hidden sm:inline">Admin</span>
                  </Link>
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                aria-label="Sair"
                onClick={async () => {
                  await supabase.auth.signOut();
                  navigate({ to: "/" });
                }}
              >
                <LogOut />
              </Button>
            </>
          ) : (
            <>
              <Button asChild variant="ghost" size="sm">
                <Link to="/auth">Entrar</Link>
              </Button>
              <Button asChild size="sm">
                <Link to="/auth" search={{ mode: "signup" }}>
                  Criar conta
                </Link>
              </Button>
            </>
          )}
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-20 bg-gradient-ink text-ink-foreground">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-10 sm:flex-row sm:items-center sm:justify-between">
        <div className="font-display text-lg font-bold">{SITE_NAME}</div>
        <p className="text-sm text-ink-foreground/70">
          Escolha seus números, pague via PIX e boa sorte!
        </p>
      </div>
    </footer>
  );
}
