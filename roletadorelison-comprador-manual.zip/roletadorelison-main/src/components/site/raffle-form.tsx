import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { ImagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { RaffleImage } from "./raffle-image";
import { errorMessage, type Raffle } from "@/lib/raffle";

export type RaffleFormValues = {
  title: string;
  description: string;
  prize: string;
  prize_2: string;
  prize_3: string;
  total_numbers: number;
  price: number;
  draw_date: string | null;
  status: string;
  image_url: string | null;
};

function toLocalInput(iso: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 16);
}

export function RaffleForm({
  initial,
  soldCount = 0,
  submitLabel,
  onSubmit,
}: {
  initial?: Raffle;
  soldCount?: number;
  submitLabel: string;
  onSubmit: (v: RaffleFormValues) => Promise<void>;
}) {
  const [v, setV] = useState({
    title: initial?.title ?? "",
    description: initial?.description ?? "",
    prize: initial?.prize ?? "",
    prize_2: initial?.prize_2 ?? "",
    prize_3: initial?.prize_3 ?? "",
    total_numbers: String(initial?.total_numbers ?? 850),
    price: String(initial?.price ?? "5.00"),
    draw_date: toLocalInput(initial?.draw_date ?? null),
    status: initial?.status ?? "active",
    image_url: initial?.image_url ?? null,
  });
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  async function upload(file: File) {
    if (!file.type.startsWith("image/")) { toast.error("Escolha um arquivo de imagem."); return; }
    if (file.size > 5 * 1024 * 1024) { toast.error("A imagem deve ter até 5 MB."); return; }
    setUploading(true);
    setPreview(URL.createObjectURL(file));
    try {
      const ext = file.type.split("/")[1]?.replace(/[^a-zA-Z0-9]/g, "") || "jpg";
      const path = `${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from("raffle-images").upload(path, file, { contentType: file.type });
      if (error) throw error;
      setV((s) => ({ ...s, image_url: path }));
      toast.success("Foto enviada.");
    } catch (error) {
      setPreview(null);
      toast.error(errorMessage(error));
    } finally {
      setUploading(false);
      if (fileInput.current) fileInput.current.value = "";
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (uploading || busy) return;
    const total = parseInt(v.total_numbers, 10);
    const price = parseFloat(v.price.replace(",", "."));
    if (!v.title.trim()) { toast.error("Informe o título da rifa."); return; }
    if (!Number.isFinite(total) || total < 1 || total > 100000) { toast.error("Quantidade de cotas entre 1 e 100.000."); return; }
    if (initial && total < initial.total_numbers && soldCount > 0)
      { toast.error("Não é possível diminuir as cotas depois que houve vendas."); return; }
    if (!Number.isFinite(price) || price < 0) { toast.error("Preço inválido."); return; }
    setBusy(true);
    try {
      await onSubmit({
        title: v.title.trim(),
        description: v.description.trim(),
        prize: v.prize.trim(),
        prize_2: v.prize_2.trim(),
        prize_3: v.prize_3.trim(),
        total_numbers: total,
        price,
        draw_date: v.draw_date ? new Date(v.draw_date).toISOString() : null,
        status: v.status,
        image_url: v.image_url,
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="grid gap-4 sm:grid-cols-2">
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="rf-title">Título da rifa</Label>
        <Input id="rf-title" value={v.title} onChange={(e) => setV({ ...v, title: e.target.value })} placeholder="Ex.: Rifa da Moto 0km" />
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="rf-prize">Prêmio do 1º lugar</Label>
        <Input id="rf-prize" value={v.prize} onChange={(e) => setV({ ...v, prize: e.target.value })} placeholder="Ex.: Honda CG 160 Start" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rf-prize2">Prêmio do 2º lugar (opcional)</Label>
        <Input id="rf-prize2" value={v.prize_2} onChange={(e) => setV({ ...v, prize_2: e.target.value })} placeholder="Ex.: R$ 500 no PIX" />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rf-prize3">Prêmio do 3º lugar (opcional)</Label>
        <Input id="rf-prize3" value={v.prize_3} onChange={(e) => setV({ ...v, prize_3: e.target.value })} placeholder="Ex.: R$ 200 no PIX" />
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label htmlFor="rf-desc">Descrição / regras</Label>
        <Textarea id="rf-desc" rows={3} value={v.description} onChange={(e) => setV({ ...v, description: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rf-total">Quantidade de cotas</Label>
        <Input id="rf-total" inputMode="numeric" value={v.total_numbers} onChange={(e) => setV({ ...v, total_numbers: e.target.value.replace(/\D/g, "") })} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rf-price">Preço por cota (R$)</Label>
        <Input id="rf-price" inputMode="decimal" value={v.price} onChange={(e) => setV({ ...v, price: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="rf-date">Data do sorteio</Label>
        <Input id="rf-date" type="datetime-local" value={v.draw_date} onChange={(e) => setV({ ...v, draw_date: e.target.value })} />
      </div>
      <div className="space-y-1.5">
        <Label>Status</Label>
        <Select value={v.status} onValueChange={(s) => setV({ ...v, status: s })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Vendas abertas</SelectItem>
            <SelectItem value="closed">Vendas encerradas</SelectItem>
            <SelectItem value="finished">Sorteada</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-1.5 sm:col-span-2">
        <Label>Foto do prêmio</Label>
        <div className="flex items-center gap-4">
          <div className="h-24 w-32 shrink-0 overflow-hidden rounded-lg border border-border">
            {preview ? <img src={preview} alt="Foto da rifa" className="h-full w-full object-cover" /> : <RaffleImage path={v.image_url} alt="Foto da rifa" />}
          </div>
          <Button type="button" variant="outline" disabled={uploading || busy} onClick={() => fileInput.current?.click()}>
            <ImagePlus className="size-4" /> {uploading ? "Enviando..." : "Escolher imagem"}
          </Button>
          <input ref={fileInput} aria-label="Foto do prêmio" type="file" accept="image/*" disabled={uploading || busy} className="hidden" onChange={(e) => { const file = e.target.files?.[0]; if (file) void upload(file); }} />
        </div>
      </div>
      <div className="sm:col-span-2">
        <Button type="submit" size="lg" disabled={busy || uploading}>{busy ? "Salvando..." : submitLabel}</Button>
      </div>
    </form>
  );
}
