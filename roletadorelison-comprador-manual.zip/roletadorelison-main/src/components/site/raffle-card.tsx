import { Link } from "@tanstack/react-router";
import { CalendarDays } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RaffleImage } from "./raffle-image";
import { formatBRL, formatDate, STATUS_LABEL, type Raffle } from "@/lib/raffle";

export function RaffleCard({ raffle, taken }: { raffle: Raffle; taken: number }) {
  const pct = Math.min(100, Math.round((taken / raffle.total_numbers) * 100));
  return (
    <Link
      to="/rifa/$id"
      params={{ id: raffle.id }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-ticket transition-transform hover:-translate-y-1"
    >
      <div className="relative aspect-[4/3] overflow-hidden">
        <RaffleImage path={raffle.image_url} alt={raffle.title} className="transition-transform duration-500 group-hover:scale-105" />
        <Badge
          variant={raffle.status === "active" ? "default" : "secondary"}
          className="absolute left-3 top-3"
        >
          {STATUS_LABEL[raffle.status] ?? raffle.status}
        </Badge>
      </div>
      <div className="flex flex-1 flex-col gap-3 p-5">
        <h3 className="text-xl font-bold leading-tight">{raffle.title}</h3>
        {raffle.prize && <p className="line-clamp-2 text-sm text-muted-foreground">{raffle.prize}</p>}
        <div className="mt-auto space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>{taken} de {raffle.total_numbers} cotas</span>
            <span>{pct}%</span>
          </div>
          <Progress value={pct} className="h-2" />
        </div>
        <div className="flex items-end justify-between border-t border-dashed border-border pt-3">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <CalendarDays className="size-3.5" /> {formatDate(raffle.draw_date)}
          </span>
          <span className="font-display text-lg font-bold text-primary">
            {formatBRL(Number(raffle.price))}
            <span className="text-xs font-medium text-muted-foreground"> /cota</span>
          </span>
        </div>
      </div>
    </Link>
  );
}
