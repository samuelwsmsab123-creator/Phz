# Sorte Grande — Roadmap

- [x] Banco de dados: perfis, papéis, rifas, cotas premiadas, cotas compradas
- [x] Chave PIX configurada no painel admin (configuração geral do site)
- [x] Cadastro/login com nome completo, e-mail e telefone
- [x] Página inicial com rifas ativas
- [x] Página da rifa: grade de números, escolha e reserva, PIX para pagamento
- [x] Minhas cotas (comprador)
- [x] Painel admin: criar/editar rifas, cotas premiadas, confirmar pagamentos, ver dados dos ganhadores, número sorteado
- [x] Corrigir escolha, prévia e exibição da foto salva da rifa
- [x] Ajustar sorteio após todas as cotas pagas, com um número diferente por lugar
- [x] Sortear cada lugar com roleta animada
- [ ] Tabela administrativa de todas as cotas, seleção e edição de pagamento e comprador
